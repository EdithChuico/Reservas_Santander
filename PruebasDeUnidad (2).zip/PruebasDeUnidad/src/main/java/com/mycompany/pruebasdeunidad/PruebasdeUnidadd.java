package com.mycompany.pruebasdeunidad;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Date;

public class PruebasdeUnidadd {
    
    @Mock
    private MongoDatabase database;
    @Mock
    private MongoCollection<Document> collection;
    @Mock
    private FindIterable<Document> documents;
    @Mock
    private MongoCursor<Document> cursor;
    @Mock
    private JTable factura;
    @Mock
    private JTextField subTotal;
    @Mock
    private JTextField total;
    @Mock
    private JTextField iva;
    @Mock
    private DefaultTableModel model;

    private PruebasDeUnidad pruebasDeUnidad;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        pruebasDeUnidad = new PruebasDeUnidad();
        // Establece la colección simulada en la instancia de PruebasDeUnidad
        pruebasDeUnidad.setDatabase(database);
        when(database.getCollection(anyString())).thenReturn(collection);
        when(collection.find(any(Document.class))).thenReturn(documents);
        when(factura.getModel()).thenReturn(model);
        when(documents.iterator()).thenReturn(cursor);
    }
    
    @Test
    public void testAgregarDatosTabla() {
        // Prepara datos de prueba
        String cood = "ABC123";
        String tipHa = "Personal";
        int dia = 3;

        // Configura los mocks
        when(collection.countDocuments(any(Document.class))).thenReturn(1L);
        Document document = new Document("Codigo", cood)
                                .append("Tipo de habitacion", "H_personal")
                                .append("Precio", 100.0);
        when(cursor.hasNext()).thenReturn(true, false);
        when(cursor.next()).thenReturn(document);

        // Llama al método a probar
        pruebasDeUnidad.agregarDatosTabla(cood, tipHa, dia, factura, subTotal, total, iva);

        // Verifica los resultados esperados
        verify(model, times(1)).addRow(any(Object[].class));
        assertEquals("300", subTotal.getText());
        assertEquals("45.0", iva.getText());
        assertEquals("345.0", total.getText());
    }

    @Test
    public void testAgregarDatosTablaHabitacionNoEncontrada() {
        // Prepara datos de prueba
        String cood = "ABC123";
        String tipHa = "Personal";
        int dia = 3;

        // Configura los mocks
        when(collection.countDocuments(any(Document.class))).thenReturn(0L);

        // Llama al método a probar
        pruebasDeUnidad.agregarDatosTabla(cood, tipHa, dia, factura, subTotal, total, iva);

        // Verifica que no se agregó ninguna fila
        verify(model, never()).addRow(any(Object[].class));
    }

    @Test
    public void testSearchActionPerformedCedulaNoValida() {
        // Prepara datos de prueba
        JTextField idSearch = mock(JTextField.class);
        when(idSearch.getText()).thenReturn("123456");

        // Simula la acción de búsqueda
        long count = 0L;
        when(collection.countDocuments(any(Document.class))).thenReturn(count);

        // Llama al método a probar
        boolean resultado = pruebasDeUnidad.searchActionPerformed(idSearch);

        // Verifica que se mostró el mensaje de error
        assertFalse(resultado);
    }

    @Test
    public void testGuardarFacBD() {
        // Prepara datos de prueba
        String nombre = "Juan";
        String telefono = "1234567890";
        String cedu = "1234567890";
        String correo = "juan@example.com";

        // Configura los mocks
        when(database.getCollection("Facturas")).thenReturn(collection);

        // Llama al método a probar
        boolean resultado = pruebasDeUnidad.guardarFacBD(nombre, telefono, cedu, correo);

        // Verifica que se insertó el documento en la colección
        verify(collection, times(1)).insertOne(any(Document.class));
        assertTrue(resultado);
    }

    @Test
    public void EstadoHabitaciones() {
         String dispo = "Disponibildad: Ocupado";
         if ("Disponibilidad: Ocupado".equals(dispo) || "Disponibilidad: Pendiente".equals(dispo)) {
        // Mostrar un mensaje de error y terminar el método
        System.out.println("ERROR La habitación seleccionada no está disponible");
        return; // Termina la ejecución del método
        // Mostrar el panel adecuado
        } 
    }
    
    public String alquilarH1(String tip, String pr) {
        // Simula el comportamiento del método
        return "Habitación: " + pr + ", Tipo: " + tip;
    }

    public String registrar(String nombre, String telefono, String cedu, String correo, Date diaInicio, Date diaFin, String precio) {
        Integer dias = 0;
        double price = 0;

        if (diaInicio != null && diaFin != null) {
            long diff = diaFin.getTime() - diaInicio.getTime();
            dias = (int) (diff / (1000 * 60 * 60 * 24));
        } else {
            return "Error: Por favor ingrese ambas fechas";
        }

        if (precio.length() >= 8) {
            String priceString = precio.substring(8).trim();
            price = Double.parseDouble(priceString);
        }

        // Lógica para crear el PDF de la proforma
       // crearPDFProforma c = new crearPDFProforma();
       // c.guardarProfBD(nombre, telefono, cedu, correo);
       // c.crearPDFProf("tipoHabitacion", "tip_Habitacion", dias, price, price * dias, "factura");

        return "Agregado: Nombre=" + nombre + ", Teléfono=" + telefono + ", Cédula=" + cedu + ", Correo=" + correo;
    }

    public String facturar(String codHab, Date diaInicio, Date diaFin, String tipHa) {
        int dias = 0;
        String precio = "jLabel9";

        if (diaInicio != null && diaFin != null) {
            long diff = diaFin.getTime() - diaInicio.getTime();
            dias = (int) (diff / (1000 * 60 * 60 * 24));
        } else {
            return "Error: Por favor ingrese ambas fechas";
        }

       // agregarDatosFa agg = new agregarDatosFa();
       // agg.agregarDatosTabla(codHab, tipHa, dias, "factura", "subTotal", "total", "iva");

        return "Facturado: Código de Habitación=" + codHab + ", Tipo=" + tipHa + ", Días=" + dias;
    }
    
}
