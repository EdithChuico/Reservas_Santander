package com.mycompany.pruebasdeunidad;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class PruebasDeUnidad {

    private MongoDatabase database;

    public static void main(String[] args) {
        
    }

    public void setDatabase(MongoDatabase database) {
        this.database = database;
    }

    public void agregarDatosTabla(String cood, String tipHa, int dia, JTable factura, JTextField subTotal, JTextField total, JTextField iva) {
        if (tipHa.equals("Personal")) {
            tipHa = "H_personal";
        } else if (tipHa.equals("Familiar")) {
            tipHa = "H_familiar";
        } else {
            tipHa = "H_matrimonial";
        }

        MongoCollection<Document> collection = database.getCollection(tipHa);
        Document query = new Document("Codigo", cood);
        long count = collection.countDocuments(query);

        if (dia <= 0) {
            System.out.println("Ingrese una cantidad de días de hospedaje correcta");
            return;
        }

        if (count <= 0) {
            System.out.println("No se encontró la habitación con el código especificado");
        } else {
            DefaultTableModel tabla1 = (DefaultTableModel) factura.getModel();
            int subtotal = 0;
            limpiarFilasVacias(tabla1);
            for (Document document : collection.find(query)) {
                String codigo = document.getString("Codigo");
                String tipoHabitacion = document.getString("Tipo de habitacion");
                Double precio = document.getDouble("Precio");
                int precioI = precio.intValue();
                subtotal = precioI * dia;

                boolean existe = false;
                for (int i = 0; i < tabla1.getRowCount(); i++) {
                    Object codigoEnTabla = tabla1.getValueAt(i, 0);
                    Object tipoHabitacionEnTabla = tabla1.getValueAt(i, 1);
                    Object diaEnTabla = tabla1.getValueAt(i, 2);
                    Object precioEnTabla = tabla1.getValueAt(i, 3);
                    if (codigo.equals(codigoEnTabla) &&
                        tipoHabitacion.equals(tipoHabitacionEnTabla) &&
                        (diaEnTabla != null && dia == (int) diaEnTabla) &&
                        (precioEnTabla != null && precio.equals(precioEnTabla))) {
                        existe = true;
                        break;
                    }
                }

                if (!existe) {
                    tabla1.addRow(new Object[]{codigo, tipoHabitacion, dia, precio, subtotal});
                    System.out.println("Habitación agregada a la factura");
                } else {
                    System.out.println("La habitación ya está en la factura");
                }
            }

            int subtotalText = 0;
            for (int i = 0; i < tabla1.getRowCount(); i++) {
                subtotalText += (int) tabla1.getValueAt(i, 4);
            }

            subTotal.setText(String.valueOf(subtotalText));
            iva.setText(String.valueOf(subtotalText * 0.15));
            total.setText(String.valueOf(subtotalText * 1.15));
            factura.setModel(tabla1);
        }
    }

    public boolean searchActionPerformed(JTextField idSearch) {
    String userID = idSearch.getText();
    Document query = new Document("Cedula", userID);
    MongoCollection<Document> collection = database.getCollection("usuarios"); 
    long count = collection.countDocuments(query);

    if (userID.length() != 10) {
        System.out.println("La cédula debe de tener 10 dígitos");
        return false;
    }

    if (count <= 0) {
        System.out.println("La cédula ingresada no está registrada");
        return false;
    }

    for (Document document : collection.find(query)) {
        System.out.println("Nombre: " + document.getString("Nombre"));
        System.out.println("Teléfono: " + document.getString("Teléfono"));
        System.out.println("Cédula: " + document.getString("Cedula"));
    }

    return true;
}


    public boolean guardarFacBD(String nombre, String telefono, String cedu, String correo) {
        MongoCollection<Document> collection = database.getCollection("Facturas");
        Document document = new Document("Nombre", nombre)
                                .append("Teléfono", telefono)
                                .append("Cédula", cedu)
                                .append("Correo", correo);

        try {
            collection.insertOne(document);
            return true;
        } catch (Exception e) {
            System.out.println("Error al guardar la factura en la base de datos");
            return false;
        }
    }

    private void limpiarFilasVacias(DefaultTableModel tabla1) {
        for (int i = tabla1.getRowCount() - 1; i >= 0; i--) {
            boolean filaVacia = true;
            for (int j = 0; j < tabla1.getColumnCount(); j++) {
                if (tabla1.getValueAt(i, j) != null) {
                    filaVacia = false;
                    break;
                }
            }
            if (filaVacia) {
                tabla1.removeRow(i);
            }
        }
    }
}
