package com.mycompany.pruebasdeunidad;

import java.util.Date;

public class PruebasDeUnidad {

    public boolean agregarDatosTabla(String cood, String tipHa, int dia) {
        if (cood.equals("ABC123") && tipHa.equals("Personal")) {
            double precio = 100.0;
            double subTotal = precio * dia;
            double iva = subTotal * 0.15;
            double total = subTotal + iva;

            System.out.println("Subtotal: " + subTotal);
            System.out.println("IVA: " + iva);
            System.out.println("Total: " + total);
            return true;
        } else {
            System.out.println("No se encontró la habitación");
            return false;
        }
    }

    public boolean searchActionPerformed(String idSearch) {
        if (idSearch.equals("123456")) {
            System.out.println("Cédula no válida");
            return false;
        }
        return true;
    }

    public boolean guardarFacBD(String nombre, String telefono, String cedu, String correo) {
        System.out.println("Factura guardada: " + nombre + ", " + telefono + ", " + cedu + ", " + correo);
        return true;
    }

    public boolean estadoHabitaciones(String dispo) {
        if ("Disponibilidad: Ocupado".equals(dispo) || "Disponibilidad: Pendiente".equals(dispo)) {
            System.out.println("ERROR: La habitación seleccionada no está disponible");
            return false;
        }
        return true;
    }

    public String alquilarH1(String tip, String pr) {
        return "Habitación: " + pr + ", Tipo: " + tip;
    }

    public String registrar(String nombre, String telefono, String cedu, String correo, Date diaInicio, Date diaFin, String precio) {
        Integer dias = 0;
        double price = 0;

        if (diaInicio != null && diaFin != null) {
            long diff = diaFin.getTime() - diaInicio.getTime();
            dias = (int) (diff / (1000 * 60 * 60 * 24));
        } else {
            return "Error: Por favor ingrese ambas fechas";
        }

        if (precio.length() >= 8) {
            String priceString = precio.substring(8).trim();
            price = Double.parseDouble(priceString);
        }

        // Lógica para crear el PDF de la proforma
        // crearPDFProforma c = new crearPDFProforma();
        // c.guardarProfBD(nombre, telefono, cedu, correo);
        // c.crearPDFProf("tipoHabitacion", "tip_Habitacion", dias, price, price * dias, "factura");

        return "Agregado: Nombre=" + nombre + ", Teléfono=" + telefono + ", Cédula=" + cedu + ", Correo=" + correo;
    }

    public String facturar(String codHab, Date diaInicio, Date diaFin, String tipHa) {
        int dias = 0;
        String precio = "jLabel9";

        if (diaInicio != null && diaFin != null) {
            long diff = diaFin.getTime() - diaInicio.getTime();
            dias = (int) (diff / (1000 * 60 * 60 * 24));
        } else {
            return "Error: Por favor ingrese ambas fechas";
        }

        // agregarDatosFa agg = new agregarDatosFa();
        // agg.agregarDatosTabla(codHab, tipHa, dias, "factura", "subTotal", "total", "iva");

        return "Facturado: Código de Habitación=" + codHab + ", Tipo=" + tipHa + ", Días=" + dias;
    }

    public static void main(String[] args) {
        PruebasDeUnidad pruebas = new PruebasDeUnidad();

        // Ejemplo de uso de los métodos
        pruebas.agregarDatosTabla("ABC123", "Personal", 3);
        pruebas.searchActionPerformed("123456");
        pruebas.guardarFacBD("Juan", "1234567890", "1234567890", "juan@example.com");
        pruebas.estadoHabitaciones("Disponibilidad: Ocupado");
    }
}
