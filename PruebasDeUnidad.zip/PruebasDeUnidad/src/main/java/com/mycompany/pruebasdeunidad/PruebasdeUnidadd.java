package com.mycompany.pruebasdeunidad;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class PruebasdeUnidadd {

    private PruebasDeUnidad pruebasDeUnidad;

    @Before
    public void setUp() {
        pruebasDeUnidad = new PruebasDeUnidad();
    }

    @Test
    public void testAgregarDatosTabla() {
        // Llama al método a probar
        boolean resultado = pruebasDeUnidad.agregarDatosTabla("ABC123", "Personal", 3);

        // Verifica los resultados esperados
        assertTrue(resultado);
    }

    @Test
    public void testAgregarDatosTablaHabitacionNoEncontrada() {
        // Llama al método a probar
        boolean resultado = pruebasDeUnidad.agregarDatosTabla("XYZ456", "Personal", 3);

        // Verifica que no se agregó ninguna fila
        assertFalse(resultado);
    }

    @Test
    public void testSearchActionPerformedCedulaNoValida() {
        // Llama al método a probar
        boolean resultado = pruebasDeUnidad.searchActionPerformed("123456");

        // Verifica que se mostró el mensaje de error
        assertFalse(resultado);
    }

    @Test
    public void testGuardarFacBD() {
        // Llama al método a probar
        boolean resultado = pruebasDeUnidad.guardarFacBD("Juan", "1234567890", "1234567890", "juan@example.com");

        // Verifica que se insertó el documento en la colección
        assertTrue(resultado);
    }

    @Test
    public void testEstadoHabitaciones() {
        boolean resultado = pruebasDeUnidad.estadoHabitaciones("Disponibilidad: Ocupado");
        assertFalse(resultado);
    }
}
