package com.mycompany.pruebasdeunidad;

import org.junit.Test;
import java.util.Date;
import static org.junit.Assert.assertEquals;

public class PruebasdeUnidadd1 {

    @Test
    public void testAlquilarH1() {
        String tip = "Personal";
        String pr = "H101";
        String resultado = "Habitación: " + pr + ", Tipo: " + tip;
        assertEquals("Habitación: H101, Tipo: Personal", resultado);
    }

    @Test
    public void testRegistrar() {
        String nombre = "Juan";
        String telefono = "1234567890";
        String cedu = "0987654321";
        String correo = "juan@example.com";
        Date inicio = new Date(2023, 7, 1);
        Date fin = new Date(2023, 7, 5);
        String precio = "Precio: 100";

        Integer dias = 0;
        double price = 0;

        if (inicio != null && fin != null) {
            long diff = fin.getTime() - inicio.getTime();
            dias = (int) (diff / (1000 * 60 * 60 * 24));
        } else {
            assertEquals("Error: Por favor ingrese ambas fechas", "Error: Por favor ingrese ambas fechas");
            return;
        }

        if (precio.length() >= 8) {
            String priceString = precio.substring(8).trim();
            price = Double.parseDouble(priceString);
        }

        String resultado = "Agregado: Nombre=" + nombre + ", Teléfono=" + telefono + ", Cédula=" + cedu + ", Correo=" + correo;
        assertEquals("Agregado: Nombre=Juan, Teléfono=1234567890, Cédula=0987654321, Correo=juan@example.com", resultado);
    }

    @Test
    public void testRegistrarError() {
        String nombre = "Juan";
        String telefono = "1234567890";
        String cedu = "0987654321";
        String correo = "juan@example.com";
        Date inicio = null;
        Date fin = null;
        String precio = "Precio: 100";

        Integer dias = 0;
        double price = 0;

        if (inicio != null && fin != null) {
            long diff = fin.getTime() - inicio.getTime();
            dias = (int) (diff / (1000 * 60 * 60 * 24));
        } else {
            assertEquals("Error: Por favor ingrese ambas fechas", "Error: Por favor ingrese ambas fechas");
            return;
        }

        if (precio.length() >= 8) {
            String priceString = precio.substring(8).trim();
            price = Double.parseDouble(priceString);
        }

        String resultado = "Agregado: Nombre=" + nombre + ", Teléfono=" + telefono + ", Cédula=" + cedu + ", Correo=" + correo;
        assertEquals("Error: Por favor ingrese ambas fechas", resultado);
    }

    @Test
    public void testFacturar() {
        String codHab = "H101";
        Date inicio = new Date(2023, 7, 1);
        Date fin = new Date(2023, 7, 5);
        String tipHa = "Personal";

        int dias = 0;
        if (inicio != null && fin != null) {
            long diff = fin.getTime() - inicio.getTime();
            dias = (int) (diff / (1000 * 60 * 60 * 24));
        } else {
            assertEquals("Error: Por favor ingrese ambas fechas", "Error: Por favor ingrese ambas fechas");
            return;
        }

        String resultado = "Facturado: Código de Habitación=" + codHab + ", Tipo=" + tipHa + ", Días=" + dias;
        assertEquals("Facturado: Código de Habitación=H101, Tipo=Personal, Días=4", resultado);
    }

    @Test
    public void testFacturarError() {
        String codHab = "H101";
        Date inicio = null;
        Date fin = null;
        String tipHa = "Personal";

        int dias = 0;
        if (inicio != null && fin != null) {
            long diff = fin.getTime() - inicio.getTime();
            dias = (int) (diff / (1000 * 60 * 60 * 24));
        } else {
            assertEquals("Error: Por favor ingrese ambas fechas", "Error: Por favor ingrese ambas fechas");
            return;
        }

        String resultado = "Facturado: Código de Habitación=" + codHab + ", Tipo=" + tipHa + ", Días=" + dias;
        assertEquals("Error: Por favor ingrese ambas fechas", resultado);
    }
}
