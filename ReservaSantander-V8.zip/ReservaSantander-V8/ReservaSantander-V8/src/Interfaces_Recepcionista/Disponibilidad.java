package Interfaces_Recepcionista;

import BD_Facturas.crearPDFFactura;
import Clases.agregarDatosFa;
import Clases.disponibilidad;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import java.util.Date;
import javax.swing.JOptionPane;
//import org.bson.Document;
public class Disponibilidad extends javax.swing.JFrame {
     private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoCollection<org.bson.Document> collection;
    //MongoCollection<org.bson.Document> collection = database.getCollection("RegistroClientes");
    public Disponibilidad() {
        initComponents();
        mongoClient = new MongoClient("localhost", 27017); 
        database = mongoClient.getDatabase("Reservas_Santander");
        collection = database.getCollection("RegistroClientes"); 
        jPanel1.setVisible(false);
        jPanel3.setVisible(false);
        HotelManagement();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        idSearch = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        search = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        id = new javax.swing.JTextField();
        phone = new javax.swing.JTextField();
        mail = new javax.swing.JTextField();
        name = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        factura = new javax.swing.JTable();
        cancelar1 = new javax.swing.JButton();
        registrar = new javax.swing.JButton();
        jLabel24 = new javax.swing.JLabel();
        subTotal = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        iva = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        total = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        cancelar = new javax.swing.JButton();
        facturar = new javax.swing.JButton();
        jLabel17 = new javax.swing.JLabel();
        tipoH = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        inicio = new com.toedter.calendar.JDateChooser();
        fin = new com.toedter.calendar.JDateChooser();
        jLabel8 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        tip_H = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        hab1 = new javax.swing.JLabel();
        alquilarH1 = new javax.swing.JButton();
        hab11 = new javax.swing.JLabel();
        hab12 = new javax.swing.JLabel();
        hab22 = new javax.swing.JLabel();
        hab23 = new javax.swing.JLabel();
        hab2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        alquilarH2 = new javax.swing.JButton();
        hab32 = new javax.swing.JLabel();
        hab33 = new javax.swing.JLabel();
        hab3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        alquilarH3 = new javax.swing.JButton();
        hab42 = new javax.swing.JLabel();
        hab43 = new javax.swing.JLabel();
        hab4 = new javax.swing.JLabel();
        alquilarH4 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        hab52 = new javax.swing.JLabel();
        hab53 = new javax.swing.JLabel();
        hab5 = new javax.swing.JLabel();
        alquilarH5 = new javax.swing.JButton();
        hab6 = new javax.swing.JLabel();
        hab72 = new javax.swing.JLabel();
        hab62 = new javax.swing.JLabel();
        hab73 = new javax.swing.JLabel();
        hab7 = new javax.swing.JLabel();
        hab82 = new javax.swing.JLabel();
        hab83 = new javax.swing.JLabel();
        hab8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        hab92 = new javax.swing.JLabel();
        hab93 = new javax.swing.JLabel();
        hab9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        hab101 = new javax.swing.JLabel();
        hab102 = new javax.swing.JLabel();
        hab10 = new javax.swing.JLabel();
        hab63 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        alquilarH6 = new javax.swing.JButton();
        alquilarH7 = new javax.swing.JButton();
        alquilarH8 = new javax.swing.JButton();
        alquilarH9 = new javax.swing.JButton();
        alquilarH10 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        cod1 = new javax.swing.JLabel();
        cod2 = new javax.swing.JLabel();
        cod3 = new javax.swing.JLabel();
        cod4 = new javax.swing.JLabel();
        cod5 = new javax.swing.JLabel();
        cod6 = new javax.swing.JLabel();
        cod7 = new javax.swing.JLabel();
        cod8 = new javax.swing.JLabel();
        cod9 = new javax.swing.JLabel();
        cod10 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        idSearch.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        idSearch.setText("Buscar cliente por su cedula ");
        idSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idSearchActionPerformed(evt);
            }
        });
        jPanel3.add(idSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 110, 460, 30));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setText("FACTURACION");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 40, -1, -1));

        search.setText("Buscar");
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchActionPerformed(evt);
            }
        });
        jPanel3.add(search, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 110, 90, 30));

        jLabel15.setText("Apellidos y Nombres");
        jPanel3.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 180, -1, -1));

        jLabel16.setText("Teléfono");
        jPanel3.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 180, -1, -1));

        jLabel21.setText("Correo Electrónico:");
        jPanel3.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 220, -1, -1));

        jLabel22.setText("Cédula");
        jPanel3.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 220, -1, -1));
        jPanel3.add(id, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 220, 260, -1));
        jPanel3.add(phone, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 180, 200, -1));
        jPanel3.add(mail, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 220, 200, -1));
        jPanel3.add(name, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 180, 260, -1));

        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel23.setText("Descripción del servicio");
        jPanel3.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 310, -1, -1));

        factura.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Código", "Tipo de habitación", "Tiempo de estadía", "Precio por noche", "Precio Total"
            }
        ));
        jScrollPane1.setViewportView(factura);

        jPanel3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 350, 790, 120));

        cancelar1.setText("Cancelar");
        cancelar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelar1ActionPerformed(evt);
            }
        });
        jPanel3.add(cancelar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 630, -1, -1));

        registrar.setText("Registrar Factura");
        registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registrarActionPerformed(evt);
            }
        });
        jPanel3.add(registrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 630, -1, -1));

        jLabel24.setText("Total");
        jPanel3.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 580, 50, 20));
        jPanel3.add(subTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 500, 90, -1));

        jLabel25.setText("Iva 15%");
        jPanel3.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 540, 50, 20));
        jPanel3.add(iva, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 540, 90, -1));

        jLabel26.setText("Subtotal");
        jPanel3.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 500, 50, 20));
        jPanel3.add(total, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 580, 90, -1));
        jPanel3.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 140, 180, 20));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 770));

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setText("Precio de la habitación");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 100, -1, -1));

        cancelar.setText("Cancelar");
        cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarActionPerformed(evt);
            }
        });
        jPanel1.add(cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 240, 150, 50));

        facturar.setText("Añadir a la facturación");
        facturar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                facturarActionPerformed(evt);
            }
        });
        jPanel1.add(facturar, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 170, 150, 50));

        jLabel17.setText("Código de Habitación");
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, -1, -1));

        tipoH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tipoHActionPerformed(evt);
            }
        });
        jPanel1.add(tipoH, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 70, 170, 20));

        jLabel19.setText("Fecha de partida");
        jPanel1.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, -1, -1));

        jLabel20.setText("Fecha de inicio");
        jPanel1.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, -1, -1));
        jPanel1.add(inicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 160, 160, -1));
        jPanel1.add(fin, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 210, 160, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setText("Datos de la habitación");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 10, -1, -1));

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel18.setText("Duración de la estadía (días)");
        jPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 110, -1, -1));

        jLabel28.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel28.setText("Precio de Habitación");
        jPanel1.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 60, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 70, -1, -1));

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setText("Ver");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(555, 31, -1, -1));

        tip_H.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Personal", "Familiar", "Matrimonial" }));
        jPanel2.add(tip_H, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 31, -1, -1));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionMar.jpg"))); // NOI18N
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 110, 170, 100));

        hab1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 230, 180, 20));

        alquilarH1.setText("Alquilar");
        alquilarH1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH1ActionPerformed(evt);
            }
        });
        jPanel2.add(alquilarH1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 310, -1, -1));

        hab11.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab11, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 250, 180, 20));

        hab12.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab12, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 270, 180, 20));

        hab22.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab22, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 250, 180, 20));

        hab23.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab23, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 270, 180, 20));

        hab2.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab2, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 230, 180, 20));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionMar.jpg"))); // NOI18N
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 110, 170, 100));

        alquilarH2.setText("Alquilar");
        alquilarH2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH2ActionPerformed(evt);
            }
        });
        jPanel2.add(alquilarH2, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 310, -1, -1));

        hab32.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab32, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 250, 180, 20));

        hab33.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab33, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 270, 180, 20));

        hab3.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab3, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 230, 180, 20));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionNmar.png"))); // NOI18N
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 90, 170, 130));

        alquilarH3.setText("Alquilar");
        alquilarH3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH3ActionPerformed(evt);
            }
        });
        jPanel2.add(alquilarH3, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 310, -1, -1));

        hab42.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab42, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 250, 180, 20));

        hab43.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab43, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 270, 180, 20));

        hab4.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab4, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 230, 180, 20));

        alquilarH4.setText("Alquilar");
        alquilarH4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH4ActionPerformed(evt);
            }
        });
        jPanel2.add(alquilarH4, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 310, -1, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionNmar.png"))); // NOI18N
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 90, 170, 130));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionNmar.png"))); // NOI18N
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 90, 170, 130));

        hab52.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab52, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 250, 180, 20));

        hab53.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab53, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 270, 180, 20));

        hab5.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 230, 180, 20));

        alquilarH5.setText("Alquilar");
        alquilarH5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH5ActionPerformed(evt);
            }
        });
        jPanel2.add(alquilarH5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 310, -1, -1));

        hab6.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab6, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 510, 180, 20));

        hab72.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab72, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 530, 180, 20));

        hab62.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab62, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 530, 180, 20));

        hab73.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab73, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 550, 180, 20));

        hab7.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab7, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 510, 180, 20));

        hab82.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab82, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 530, 180, 20));

        hab83.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab83, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 550, 180, 20));

        hab8.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab8, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 510, 180, 20));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionNmar.png"))); // NOI18N
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 370, 170, 130));

        hab92.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab92, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 530, 180, 20));

        hab93.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab93, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 550, 180, 20));

        hab9.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab9, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 510, 180, 20));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionNmar.png"))); // NOI18N
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 370, 170, 130));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionNmar.png"))); // NOI18N
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 370, 170, 130));

        hab101.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab101, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 530, 180, 20));

        hab102.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab102, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 550, 180, 20));

        hab10.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab10, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 510, 180, 20));

        hab63.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.add(hab63, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 550, 180, 20));

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionNmar.png"))); // NOI18N
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 370, 170, 130));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionNmar.png"))); // NOI18N
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 370, 170, 130));

        alquilarH6.setText("Alquilar");
        alquilarH6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH6ActionPerformed(evt);
            }
        });
        jPanel2.add(alquilarH6, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 590, -1, -1));

        alquilarH7.setText("Alquilar");
        alquilarH7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH7ActionPerformed(evt);
            }
        });
        jPanel2.add(alquilarH7, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 590, -1, -1));

        alquilarH8.setText("Alquilar");
        alquilarH8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH8ActionPerformed(evt);
            }
        });
        jPanel2.add(alquilarH8, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 590, -1, -1));

        alquilarH9.setText("Alquilar");
        alquilarH9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH9ActionPerformed(evt);
            }
        });
        jPanel2.add(alquilarH9, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 590, -1, -1));

        alquilarH10.setText("Alquilar");
        alquilarH10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH10ActionPerformed(evt);
            }
        });
        jPanel2.add(alquilarH10, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 590, -1, -1));

        jButton2.setText("Volver");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 110, 30));

        jButton3.setText("Ir a Facturación");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 650, 130, 40));
        jPanel2.add(cod1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 90, 130, 20));
        jPanel2.add(cod2, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 90, 120, 20));
        jPanel2.add(cod3, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 70, 120, 20));
        jPanel2.add(cod4, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 70, 130, 20));
        jPanel2.add(cod5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 70, 130, 20));
        jPanel2.add(cod6, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 350, 110, 20));
        jPanel2.add(cod7, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 350, 120, 20));
        jPanel2.add(cod8, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 350, 130, 20));
        jPanel2.add(cod9, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 350, 130, 20));
        jPanel2.add(cod10, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 350, 130, 20));

        jLabel1.setText("Tipo de Habitación a alquilar ");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(217, 34, -1, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 770));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    String tipHa = tip_H.getSelectedItem().toString();
    disponibilidad d= new disponibilidad ();
    d.seedisp(tipHa,hab1, hab11, hab12, hab10, hab101,hab102, hab2,hab22, hab23, hab3,hab32,hab33, hab4,hab42,hab43,hab5,hab52,hab53,hab6,hab62,hab63,hab7,hab72,hab73,hab8,hab82,hab83,hab9,hab92,hab93,cod1,cod2,cod3,cod4,cod5,cod6,cod7,cod8,cod9,cod10);
       
    }//GEN-LAST:event_jButton1ActionPerformed

    private void alquilarH4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH4ActionPerformed
    String tip=cod4.getText();
    String pr=hab42.getText();
    jLabel9.setText(pr);
    tipoH.setText(tip);
    jPanel1.setVisible(true);
    jPanel2.setVisible(false);
    jPanel3.setVisible(false);// TODO add your handling code here:
    }//GEN-LAST:event_alquilarH4ActionPerformed

    private void alquilarH5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH5ActionPerformed
    String tip=cod5.getText();
    String pr=hab52.getText();
    jLabel9.setText(pr);
    tipoH.setText(tip);
    jPanel1.setVisible(true);
    jPanel2.setVisible(false);
    jPanel3.setVisible(false);// TODO add your handling code here:
    }//GEN-LAST:event_alquilarH5ActionPerformed

    private void alquilarH6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH6ActionPerformed
    String tip=cod6.getText();
    String pr=hab62.getText();
    jLabel9.setText(pr);
    tipoH.setText(tip);
    jPanel1.setVisible(true);
    jPanel2.setVisible(false);
    jPanel3.setVisible(false);// TODO add your handling code here:
    }//GEN-LAST:event_alquilarH6ActionPerformed

    private void alquilarH7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH7ActionPerformed
    String tip=cod7.getText();
    String pr=hab72.getText();
    jLabel9.setText(pr);
    tipoH.setText(tip);
    jPanel1.setVisible(true);
    jPanel2.setVisible(false);
    jPanel3.setVisible(false);// TODO add your handling code here:
    }//GEN-LAST:event_alquilarH7ActionPerformed

    private void alquilarH8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH8ActionPerformed
    String tip=cod8.getText();
    String pr=hab82.getText();
    jLabel9.setText(pr);
    tipoH.setText(tip);
    jPanel1.setVisible(true);
    jPanel2.setVisible(false);
    jPanel3.setVisible(false);// TODO add your handling code here:
    }//GEN-LAST:event_alquilarH8ActionPerformed

    private void alquilarH9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH9ActionPerformed
    String tip=cod9.getText();
    String pr=hab92.getText();
    jLabel9.setText(pr);
    tipoH.setText(tip);
    jPanel1.setVisible(true);
    jPanel2.setVisible(false);
    jPanel3.setVisible(false);// TODO add your handling code here:
    }//GEN-LAST:event_alquilarH9ActionPerformed

    private void alquilarH10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH10ActionPerformed
    String tip=cod10.getText();
    String pr=hab101.getText();
    jLabel9.setText(pr);
    tipoH.setText(tip);
    jPanel1.setVisible(true);
    jPanel2.setVisible(false);
    jPanel3.setVisible(false);// TODO add your handling code here:
    }//GEN-LAST:event_alquilarH10ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    Principal_Hotel p=new Principal_Hotel();
    p.setVisible(true);
    p.setLocationRelativeTo(null);
    this.dispose();
// TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
    jPanel3.setVisible(true);
    jPanel2.setVisible(false);
    jPanel1.setVisible(false);
// TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed
    private void tipoHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tipoHActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tipoHActionPerformed
    private void alquilarH1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH1ActionPerformed
    String tip=cod1.getText();
    String pr=hab11.getText();
    jLabel9.setText(pr);
    tipoH.setText(tip);
    jPanel1.setVisible(true);
    jPanel2.setVisible(false);
    jPanel3.setVisible(false);
     // TODO add your handling code here:
    }//GEN-LAST:event_alquilarH1ActionPerformed
    private void cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarActionPerformed
    jPanel2.setVisible(true);
    jPanel1.setVisible(false); 
    jPanel3.setVisible(false);
    jLabel9.setText("");
    tipoH.setText("");
     // TODO add your handling code here:
    }//GEN-LAST:event_cancelarActionPerformed
    private void alquilarH2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH2ActionPerformed
    String tip=cod2.getText();
    String pr=hab22.getText();
    jLabel9.setText(pr);
    tipoH.setText(tip);
    jPanel1.setVisible(true);
    jPanel2.setVisible(false);
    jPanel3.setVisible(false);// TODO add your handling code here:
    }//GEN-LAST:event_alquilarH2ActionPerformed
    private void alquilarH3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH3ActionPerformed
    String tip=cod3.getText();
    String pr=hab32.getText();
    jLabel9.setText(pr);
    tipoH.setText(tip);
    jPanel1.setVisible(true);
    jPanel2.setVisible(false);
    jPanel3.setVisible(false);// TODO add your handling code here:
    }//GEN-LAST:event_alquilarH3ActionPerformed
    public void HotelManagement() {
        // Inicialización de los componentes
        
        // Configurar el listener para el JDateChooser de inicio
        inicio.addPropertyChangeListener("date", evt -> {
            Date diaInicio = inicio.getDate();
            if (diaInicio != null) {
                fin.setMinSelectableDate(diaInicio); // Bloquear fechas anteriores
            }
        });
    }
    String precio;
    private void facturarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_facturarActionPerformed
    String codHab=tipoH.getText();
     Date diaInicio = inicio.getDate();  // Obtén la fecha de inicio
        Date diaFin = fin.getDate();        // Obtén la fecha de fin
         int dias = 0;
     precio=jLabel9.getText();     
        if (diaInicio != null && diaFin != null) {
            long diff = diaFin.getTime() - diaInicio.getTime();
             dias = (int)(diff / (1000 * 60 * 60 * 24)); // Muestra el total de días
        } else {
            JOptionPane.showMessageDialog(this, "Por favor ingrese ambas fechas", "Error", JOptionPane.ERROR_MESSAGE);
        }  
    String tipHa = tip_H.getSelectedItem().toString();
    agregarDatosFa agg=new agregarDatosFa();
    agg.agregarDatosTabla(codHab,tipHa, dias,factura, subTotal, total,iva);
    // TODO add your handling code here:
    }//GEN-LAST:event_facturarActionPerformed

    private void idSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idSearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idSearchActionPerformed

    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed
        String userID = idSearch.getText();
         org.bson.Document query = new  org.bson.Document("Cedula", userID);
        long count= collection.countDocuments(query);
        if(userID.length()!=10 ){
            JOptionPane.showMessageDialog(null, "La cedula debe de tener 10 digitos", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }else{

            if(count<=0){
                JOptionPane.showMessageDialog(null, "La cedula ingresada no esta registrada", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }else{
                FindIterable< org.bson.Document> documents = collection.find(query);
                if (documents.iterator().hasNext()) {
                    for (org.bson.Document document : documents) {
                        name.setText(document.getString("Nombre"));
                        phone.setText(document.getString("Teléfono"));
                        id.setText(document.getString("Cedula"));
                    }
                    jLabel27.setText("¡Resultado encontrado!");
                }
            }}  // TODO add your handling code here:
    }//GEN-LAST:event_searchActionPerformed

    private void cancelar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelar1ActionPerformed
    jPanel1.setVisible(false);
    jPanel2.setVisible(true);
    jPanel3.setVisible(false);    // TODO add your handling code here:
    }//GEN-LAST:event_cancelar1ActionPerformed

    private void registrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registrarActionPerformed
    String nombre=name.getText();
    String telefono=phone.getText();
    String cedu=id.getText();
    String correo=mail.getText();
    Integer dias = 0;
    Date diaInicio = inicio.getDate();  // Obtén la fecha de inicio
    Date diaFin = fin.getDate();  
    double price=0;    
        if (diaInicio != null && diaFin != null) {
            long diff = diaFin.getTime() - diaInicio.getTime();
             dias = (int)(diff / (1000 * 60 * 60 * 24)); // Muestra el total de días
        } else {
            JOptionPane.showMessageDialog(this, "Por favor ingrese ambas fechas", "Error", JOptionPane.ERROR_MESSAGE);
        }
    // Verifica que el texto tenga al menos 9 caracteres
    if (precio.length() >= 8) {
    String priceString = precio.substring(8).trim(); // Extrae el texto a partir del noveno carácter y elimina espacios en blanco
        // Convierte el texto del precio a double
         price = Double.parseDouble(priceString);
        System.out.println("Precio extraído: " + price); // Imprime el precio
    }
    
    
    crearPDFFactura c=new crearPDFFactura();
    c.guardarFacBD(nombre, telefono, cedu, correo);
    c.crearPDF(tipoH.getText(), tip_H.getSelectedItem().toString(), dias, price, price*(double)dias, factura);
    JOptionPane.showMessageDialog(this, "Agregado", "Exito", JOptionPane.INFORMATION_MESSAGE);    
    // TODO add your handling code here:
    }//GEN-LAST:event_registrarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Disponibilidad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Disponibilidad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Disponibilidad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Disponibilidad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Disponibilidad().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton alquilarH1;
    private javax.swing.JButton alquilarH10;
    private javax.swing.JButton alquilarH2;
    private javax.swing.JButton alquilarH3;
    private javax.swing.JButton alquilarH4;
    private javax.swing.JButton alquilarH5;
    private javax.swing.JButton alquilarH6;
    private javax.swing.JButton alquilarH7;
    private javax.swing.JButton alquilarH8;
    private javax.swing.JButton alquilarH9;
    private javax.swing.JButton cancelar;
    private javax.swing.JButton cancelar1;
    private javax.swing.JLabel cod1;
    private javax.swing.JLabel cod10;
    private javax.swing.JLabel cod2;
    private javax.swing.JLabel cod3;
    private javax.swing.JLabel cod4;
    private javax.swing.JLabel cod5;
    private javax.swing.JLabel cod6;
    private javax.swing.JLabel cod7;
    private javax.swing.JLabel cod8;
    private javax.swing.JLabel cod9;
    private javax.swing.JTable factura;
    private javax.swing.JButton facturar;
    private com.toedter.calendar.JDateChooser fin;
    private javax.swing.JLabel hab1;
    private javax.swing.JLabel hab10;
    private javax.swing.JLabel hab101;
    private javax.swing.JLabel hab102;
    private javax.swing.JLabel hab11;
    private javax.swing.JLabel hab12;
    private javax.swing.JLabel hab2;
    private javax.swing.JLabel hab22;
    private javax.swing.JLabel hab23;
    private javax.swing.JLabel hab3;
    private javax.swing.JLabel hab32;
    private javax.swing.JLabel hab33;
    private javax.swing.JLabel hab4;
    private javax.swing.JLabel hab42;
    private javax.swing.JLabel hab43;
    private javax.swing.JLabel hab5;
    private javax.swing.JLabel hab52;
    private javax.swing.JLabel hab53;
    private javax.swing.JLabel hab6;
    private javax.swing.JLabel hab62;
    private javax.swing.JLabel hab63;
    private javax.swing.JLabel hab7;
    private javax.swing.JLabel hab72;
    private javax.swing.JLabel hab73;
    private javax.swing.JLabel hab8;
    private javax.swing.JLabel hab82;
    private javax.swing.JLabel hab83;
    private javax.swing.JLabel hab9;
    private javax.swing.JLabel hab92;
    private javax.swing.JLabel hab93;
    private javax.swing.JTextField id;
    private javax.swing.JTextField idSearch;
    private com.toedter.calendar.JDateChooser inicio;
    private javax.swing.JTextField iva;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField mail;
    private javax.swing.JTextField name;
    private javax.swing.JTextField phone;
    private javax.swing.JButton registrar;
    private javax.swing.JButton search;
    private javax.swing.JTextField subTotal;
    private javax.swing.JComboBox<String> tip_H;
    private javax.swing.JTextField tipoH;
    private javax.swing.JTextField total;
    // End of variables declaration//GEN-END:variables
}
