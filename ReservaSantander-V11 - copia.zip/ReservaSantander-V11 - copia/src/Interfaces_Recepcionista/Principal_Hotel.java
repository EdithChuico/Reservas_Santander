package Interfaces_Recepcionista;

import BD_Facturas.crearPDFFactura;
import Clases.agregarDatosFa;
import Clases.disponibilidad;
import Interfaces_Admin.GestionAdmin;
import Interfaces_Admin.codeAdmin;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import java.awt.Dimension;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Toolkit;
import java.util.Date;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import tipografias.Fuentes;

public class Principal_Hotel extends javax.swing.JFrame {
    
    Fuentes tipoFuente;
    ImageIcon icon = new ImageIcon("src/Imagenes/HotelSantanderIcon.png");
     private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoCollection<org.bson.Document> collection;
    public Principal_Hotel() {
        initComponents();
        mongoClient = new MongoClient("localhost", 27017); 
        database = mongoClient.getDatabase("Reservas_Santander");
        collection = database.getCollection("RegistroClientes"); 
        DatosHP.setVisible(false);
        facturaP.setVisible(false);
        habDis.setVisible(false);
        InformationPanel1.setVisible(false);
        tipoFuente = new Fuentes();
        this.setLocationRelativeTo(null);
        //this.setExtendedState(MAXIMIZED_BOTH);
        this.setTitle("Hotel Santander");
        HotelManagement();
        this.setIconImage(icon.getImage());
        
        //update text font
        RentB.setFont(tipoFuente.fuente(tipoFuente.QS,1,25));
        InformationB.setFont(tipoFuente.fuente(tipoFuente.QS,1,18));
        //CleanningB.setFont(tipoFuente.fuente(tipoFuente.QS,1,18));
       
        FormB.setFont(tipoFuente.fuente(tipoFuente.QS,1,18));
        FormB1.setFont(tipoFuente.fuente(tipoFuente.QS,1,18));
        SwitchAccountB.setFont(tipoFuente.fuente(tipoFuente.QS,1,18));
        SwitchAccountB1.setFont(tipoFuente.fuente(tipoFuente.QS,1,18));
    }
    
   /* public void setResolution(){
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        
        // Obtener el dispositivo gráfico principal
        GraphicsDevice[] gs = ge.getScreenDevices();
        for (GraphicsDevice gd : gs) {
            // Obtener la configuración de pantalla del dispositivo
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            
            // Obtener el ancho y alto de la pantalla
            int width = screenSize.width;
            int height = screenSize.height;
            
            // Imprimir la resolución de la pantalla
            System.out.println("Resolución de la pantalla: " + width + "x" + height);
        }
    }*/

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton2 = new javax.swing.JButton();
        LateralPanel = new javax.swing.JPanel();
        InformationB = new javax.swing.JButton();
        FormB = new javax.swing.JButton();
        SwitchAccountB = new javax.swing.JButton();
        SwitchAccountB1 = new javax.swing.JButton();
        FormB1 = new javax.swing.JButton();
        LogoLateralPanelL = new javax.swing.JLabel();
        MainPanel = new javax.swing.JPanel();
        RentB = new javax.swing.JButton();
        LogoL = new javax.swing.JLabel();
        DatosHP = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        cancelar = new javax.swing.JButton();
        facturar = new javax.swing.JButton();
        tipoH = new javax.swing.JTextField();
        inicio = new com.toedter.calendar.JDateChooser();
        fin = new com.toedter.calendar.JDateChooser();
        jLabel35 = new javax.swing.JLabel();
        facturaP = new javax.swing.JPanel();
        idSearch = new javax.swing.JTextField();
        search = new javax.swing.JButton();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        id = new javax.swing.JTextField();
        phone = new javax.swing.JTextField();
        mail = new javax.swing.JTextField();
        name = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        factura = new javax.swing.JTable();
        cancelar1 = new javax.swing.JButton();
        registrar = new javax.swing.JButton();
        jLabel31 = new javax.swing.JLabel();
        subTotal = new javax.swing.JTextField();
        jLabel32 = new javax.swing.JLabel();
        iva = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        total = new javax.swing.JTextField();
        jLabel34 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        InformationPanel1 = new javax.swing.JPanel();
        SimpleRoomL3 = new javax.swing.JLabel();
        SimpleRoomL4 = new javax.swing.JLabel();
        SimpleRoomL5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        volverM = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        habDis = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        tip_H = new javax.swing.JComboBox<>();
        jLabel41 = new javax.swing.JLabel();
        hab1 = new javax.swing.JLabel();
        alquilarH1 = new javax.swing.JButton();
        hab11 = new javax.swing.JLabel();
        hab12 = new javax.swing.JLabel();
        hab22 = new javax.swing.JLabel();
        hab23 = new javax.swing.JLabel();
        hab2 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        alquilarH2 = new javax.swing.JButton();
        hab32 = new javax.swing.JLabel();
        hab33 = new javax.swing.JLabel();
        hab3 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        alquilarH3 = new javax.swing.JButton();
        hab42 = new javax.swing.JLabel();
        hab43 = new javax.swing.JLabel();
        hab4 = new javax.swing.JLabel();
        alquilarH4 = new javax.swing.JButton();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        hab52 = new javax.swing.JLabel();
        hab53 = new javax.swing.JLabel();
        hab5 = new javax.swing.JLabel();
        alquilarH5 = new javax.swing.JButton();
        hab6 = new javax.swing.JLabel();
        hab72 = new javax.swing.JLabel();
        hab62 = new javax.swing.JLabel();
        hab73 = new javax.swing.JLabel();
        hab7 = new javax.swing.JLabel();
        hab82 = new javax.swing.JLabel();
        hab83 = new javax.swing.JLabel();
        hab8 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        hab92 = new javax.swing.JLabel();
        hab93 = new javax.swing.JLabel();
        hab9 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        hab101 = new javax.swing.JLabel();
        hab102 = new javax.swing.JLabel();
        hab10 = new javax.swing.JLabel();
        hab63 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        alquilarH6 = new javax.swing.JButton();
        alquilarH7 = new javax.swing.JButton();
        alquilarH8 = new javax.swing.JButton();
        alquilarH9 = new javax.swing.JButton();
        alquilarH10 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        cod1 = new javax.swing.JLabel();
        cod2 = new javax.swing.JLabel();
        cod3 = new javax.swing.JLabel();
        cod4 = new javax.swing.JLabel();
        cod5 = new javax.swing.JLabel();
        cod6 = new javax.swing.JLabel();
        cod7 = new javax.swing.JLabel();
        cod8 = new javax.swing.JLabel();
        cod9 = new javax.swing.JLabel();
        cod10 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1380, 768));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton2.setBorder(null);
        jButton2.setOpaque(false);
        jButton2.setContentAreaFilled(false);
        jButton2.setBorderPainted(false);
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton2.setForeground(new java.awt.Color(51, 51, 51));
        jButton2.setText("X");
        jButton2.setToolTipText("");
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1317, 0, 50, 40));

        LateralPanel.setBackground(new java.awt.Color(255, 255, 255));
        LateralPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        InformationB.setBackground(new java.awt.Color(73, 114, 116));
        InformationB.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        InformationB.setForeground(new java.awt.Color(255, 255, 255));
        InformationB.setText("Informacion");
        InformationB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InformationBActionPerformed(evt);
            }
        });
        LateralPanel.add(InformationB, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 360, 290, 40));

        FormB.setBackground(new java.awt.Color(73, 114, 116));
        FormB.setForeground(new java.awt.Color(255, 255, 255));
        FormB.setText("Proforma");
        FormB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FormBActionPerformed(evt);
            }
        });
        LateralPanel.add(FormB, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 430, 290, 40));

        SwitchAccountB.setBackground(new java.awt.Color(73, 114, 116));
        SwitchAccountB.setForeground(new java.awt.Color(255, 255, 255));
        SwitchAccountB.setText("Logout");
        SwitchAccountB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SwitchAccountBActionPerformed(evt);
            }
        });
        LateralPanel.add(SwitchAccountB, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 650, 290, 50));

        SwitchAccountB1.setBackground(new java.awt.Color(73, 114, 116));
        SwitchAccountB1.setForeground(new java.awt.Color(255, 255, 255));
        SwitchAccountB1.setText("Gestiones Administrador");
        SwitchAccountB1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SwitchAccountB1ActionPerformed(evt);
            }
        });
        LateralPanel.add(SwitchAccountB1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 570, 290, 40));

        FormB1.setBackground(new java.awt.Color(73, 114, 116));
        FormB1.setForeground(new java.awt.Color(255, 255, 255));
        FormB1.setText("CheckOut y Limpieza");
        FormB1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FormB1ActionPerformed(evt);
            }
        });
        LateralPanel.add(FormB1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 500, 290, 40));

        LogoLateralPanelL.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/lateralMenu.png"))); // NOI18N
        LateralPanel.add(LogoLateralPanelL, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 370, 768));

        getContentPane().add(LateralPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 370, 768));

        MainPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        RentB.setBackground(new java.awt.Color(73, 114, 116));
        RentB.setForeground(new java.awt.Color(255, 255, 255));
        RentB.setText("Alquilar");
        RentB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RentBActionPerformed(evt);
            }
        });
        MainPanel.add(RentB, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 530, 450, 120));

        LogoL.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/menu.png"))); // NOI18N
        MainPanel.add(LogoL, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1000, 770));

        getContentPane().add(MainPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 0, 1000, 768));

        DatosHP.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel13.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel13.setText("Precio de la habitación");
        DatosHP.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 250, 240, 30));

        cancelar.setForeground(new java.awt.Color(0, 0, 1));
        cancelar.setText("Cancelar");
        cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarActionPerformed(evt);
            }
        });
        DatosHP.add(cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 550, 200, 90));

        facturar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        facturar.setForeground(new java.awt.Color(0, 0, 1));
        facturar.setText("Añadir a la facturación");
        facturar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                facturarActionPerformed(evt);
            }
        });
        DatosHP.add(facturar, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 440, 200, 90));

        tipoH.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        tipoH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tipoHActionPerformed(evt);
            }
        });
        DatosHP.add(tipoH, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 200, 200, 30));
        DatosHP.add(inicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 350, 240, 30));
        DatosHP.add(fin, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 430, 240, 30));

        jLabel35.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/tiempoEstadía.png"))); // NOI18N
        DatosHP.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1366, 768));

        getContentPane().add(DatosHP, new org.netbeans.lib.awtextra.AbsoluteConstraints(-2, 1, -1, 770));

        facturaP.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        idSearch.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        idSearch.setText("Buscar cliente por su cedula ");
        idSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idSearchActionPerformed(evt);
            }
        });
        facturaP.add(idSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 150, 460, 30));

        search.setForeground(new java.awt.Color(0, 0, 1));
        search.setText("Buscar");
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchActionPerformed(evt);
            }
        });
        facturaP.add(search, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 150, 90, 30));

        jLabel27.setText("Teléfono:");
        facturaP.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 220, -1, -1));

        jLabel28.setText("Correo Electrónico:");
        facturaP.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 260, -1, -1));

        jLabel29.setText("Cédula:");
        facturaP.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 260, -1, -1));

        jLabel36.setText("Nombre:");
        facturaP.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 220, -1, -1));
        facturaP.add(id, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 260, 260, -1));
        facturaP.add(phone, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 220, 200, -1));
        facturaP.add(mail, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 260, 200, -1));
        facturaP.add(name, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 220, 260, -1));

        jLabel30.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel30.setText("Descripción del servicio");
        facturaP.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 340, -1, -1));

        factura.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Código", "Tipo de habitación", "Tiempo de estadía", "Precio por noche", "Precio Total"
            }
        ));
        jScrollPane1.setViewportView(factura);

        facturaP.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 390, 790, 120));

        cancelar1.setForeground(new java.awt.Color(0, 0, 1));
        cancelar1.setText("Cancelar");
        cancelar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelar1ActionPerformed(evt);
            }
        });
        facturaP.add(cancelar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 670, -1, -1));

        registrar.setForeground(new java.awt.Color(0, 0, 1));
        registrar.setText("Registrar Factura");
        registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registrarActionPerformed(evt);
            }
        });
        facturaP.add(registrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 670, -1, -1));

        jLabel31.setText("Total");
        facturaP.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 620, 50, 20));
        facturaP.add(subTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 540, 90, -1));

        jLabel32.setText("Iva 15%");
        facturaP.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 580, 50, 20));
        facturaP.add(iva, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 580, 90, -1));

        jLabel33.setText("Subtotal");
        facturaP.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 540, 50, 20));
        facturaP.add(total, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 620, 90, -1));
        facturaP.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 180, 180, 20));

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/facturacion.png"))); // NOI18N
        jLabel26.setText("\n");
        facturaP.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1370, 770));

        getContentPane().add(facturaP, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 770));

        InformationPanel1.setBackground(new java.awt.Color(255, 255, 255));
        InformationPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        SimpleRoomL3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/HabMat.jpg"))); // NOI18N
        SimpleRoomL3.setText("exampleimage3");
        InformationPanel1.add(SimpleRoomL3, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 140, 220, 220));

        SimpleRoomL4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habPersonal.jpg"))); // NOI18N
        SimpleRoomL4.setText("exampleimage1");
        InformationPanel1.add(SimpleRoomL4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 140, 220, 220));

        SimpleRoomL5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/HabFam.jpg"))); // NOI18N
        SimpleRoomL5.setText("exampleimage2");
        InformationPanel1.add(SimpleRoomL5, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 140, 220, 220));

        jLabel1.setText("Disponibilidad de cama adicional");
        InformationPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 590, -1, 20));

        jLabel2.setText("$$ 60-70");
        InformationPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 370, -1, -1));

        jLabel3.setText("Descripcion");
        InformationPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 410, -1, -1));

        jLabel4.setText("Habitacion Familiar");
        InformationPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 100, -1, -1));

        jLabel5.setText("Descripcion");
        InformationPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 400, -1, -1));

        jLabel6.setText("Habitacion Matrimonial");
        InformationPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 100, -1, -1));

        volverM.setText("Volver");
        volverM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                volverMActionPerformed(evt);
            }
        });
        InformationPanel1.add(volverM, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 0, -1, -1));

        jLabel7.setText("Descripcion");
        InformationPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 410, -1, -1));

        jLabel12.setText("2 Habitaciones con vista al mar");
        InformationPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 470, -1, 20));

        jLabel14.setText("2 Habitaciones con vista al mar");
        InformationPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 470, -1, 20));

        jLabel15.setText("Selección de almohadas en la habitación");
        InformationPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 500, -1, 20));

        jLabel16.setText("Wifi Gratis");
        InformationPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 530, -1, 20));

        jLabel18.setText("1 Cama matrimonial ");
        InformationPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 440, -1, 20));

        jLabel17.setText("Area de estar");
        InformationPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 560, -1, 20));

        jLabel19.setText("Wifi Gratis");
        InformationPanel1.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 530, -1, 20));

        jLabel20.setText("2 Habitaciones con vista al mar");
        InformationPanel1.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 470, -1, 20));

        jLabel21.setText("Selección de almohadas en la habitación");
        InformationPanel1.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 500, -1, 20));

        jLabel22.setText("Disponibilidad de cama adicional");
        InformationPanel1.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 560, -1, 20));

        jLabel23.setText("Wifi Gratis");
        InformationPanel1.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 500, -1, 20));

        jLabel24.setText("1 Cama individual");
        InformationPanel1.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 440, -1, 20));

        jLabel25.setText("1 Cama matrimonial y 2 camas personales");
        InformationPanel1.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 440, -1, 20));

        jLabel8.setText("Habitación Personal");
        InformationPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 110, -1, -1));

        jLabel9.setText("$$ 30-40");
        InformationPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 370, -1, -1));

        jLabel10.setText("$$ 80-100");
        InformationPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 370, -1, -1));

        getContentPane().add(InformationPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 0, 1000, 770));

        habDis.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton3.setForeground(new java.awt.Color(0, 0, 1));
        jButton3.setText("Ver");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        habDis.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 30, -1, -1));

        tip_H.setForeground(new java.awt.Color(0, 0, 1));
        tip_H.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Personal", "Familiar", "Matrimonial" }));
        habDis.add(tip_H, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 30, -1, -1));

        jLabel41.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionMar.jpg"))); // NOI18N
        habDis.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 110, 170, 100));

        hab1.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 250, 180, 20));

        alquilarH1.setForeground(new java.awt.Color(0, 0, 1));
        alquilarH1.setText("Alquilar");
        alquilarH1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH1ActionPerformed(evt);
            }
        });
        habDis.add(alquilarH1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 320, -1, -1));

        hab11.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab11, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 270, 180, 20));

        hab12.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab12, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 290, 180, 20));

        hab22.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab22, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 270, 180, 20));

        hab23.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab23, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 290, 180, 20));

        hab2.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab2, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 250, 180, 20));

        jLabel42.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionMar.jpg"))); // NOI18N
        habDis.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 110, 170, 100));

        alquilarH2.setForeground(new java.awt.Color(0, 0, 1));
        alquilarH2.setText("Alquilar");
        alquilarH2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH2ActionPerformed(evt);
            }
        });
        habDis.add(alquilarH2, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 320, -1, -1));

        hab32.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab32, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 270, 180, 20));

        hab33.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab33, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 290, 180, 20));

        hab3.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab3, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 250, 180, 20));

        jLabel43.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionNmar.png"))); // NOI18N
        habDis.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 110, 170, 130));

        alquilarH3.setForeground(new java.awt.Color(0, 0, 1));
        alquilarH3.setText("Alquilar");
        alquilarH3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH3ActionPerformed(evt);
            }
        });
        habDis.add(alquilarH3, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 320, -1, -1));

        hab42.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab42, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 270, 180, 20));

        hab43.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab43, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 290, 180, 20));

        hab4.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab4, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 250, 180, 20));

        alquilarH4.setForeground(new java.awt.Color(0, 0, 1));
        alquilarH4.setText("Alquilar");
        alquilarH4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH4ActionPerformed(evt);
            }
        });
        habDis.add(alquilarH4, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 320, -1, -1));

        jLabel44.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionNmar.png"))); // NOI18N
        habDis.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 110, 170, 130));

        jLabel45.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionNmar.png"))); // NOI18N
        habDis.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 110, 170, 130));

        hab52.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab52, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 270, 180, 20));

        hab53.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab53, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 290, 180, 20));

        hab5.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 250, 180, 20));

        alquilarH5.setForeground(new java.awt.Color(0, 0, 1));
        alquilarH5.setText("Alquilar");
        alquilarH5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH5ActionPerformed(evt);
            }
        });
        habDis.add(alquilarH5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1200, 320, -1, -1));

        hab6.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 550, 180, 20));

        hab72.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab72, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 570, 180, 20));

        hab62.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab62, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 570, 180, 20));

        hab73.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab73, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 590, 180, 20));

        hab7.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab7, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 550, 180, 20));

        hab82.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab82, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 570, 180, 20));

        hab83.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab83, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 590, 180, 20));

        hab8.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab8, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 550, 180, 20));

        jLabel46.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionNmar.png"))); // NOI18N
        habDis.add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 410, 170, 130));

        hab92.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab92, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 570, 180, 20));

        hab93.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab93, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 590, 180, 20));

        hab9.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab9, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 550, 180, 20));

        jLabel47.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionNmar.png"))); // NOI18N
        habDis.add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 410, 170, 130));

        jLabel48.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionNmar.png"))); // NOI18N
        habDis.add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 410, 170, 130));

        hab101.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab101, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 570, 180, 20));

        hab102.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab102, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 590, 180, 20));

        hab10.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab10, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 550, 180, 20));

        hab63.setBackground(new java.awt.Color(204, 204, 255));
        habDis.add(hab63, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 590, 180, 20));

        jLabel49.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionNmar.png"))); // NOI18N
        habDis.add(jLabel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 410, 170, 130));

        jLabel50.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habitacionNmar.png"))); // NOI18N
        habDis.add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 410, 170, 130));

        alquilarH6.setForeground(new java.awt.Color(0, 0, 1));
        alquilarH6.setText("Alquilar");
        alquilarH6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH6ActionPerformed(evt);
            }
        });
        habDis.add(alquilarH6, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 620, -1, -1));

        alquilarH7.setForeground(new java.awt.Color(0, 0, 1));
        alquilarH7.setText("Alquilar");
        alquilarH7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH7ActionPerformed(evt);
            }
        });
        habDis.add(alquilarH7, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 620, -1, -1));

        alquilarH8.setForeground(new java.awt.Color(0, 0, 1));
        alquilarH8.setText("Alquilar");
        alquilarH8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH8ActionPerformed(evt);
            }
        });
        habDis.add(alquilarH8, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 620, -1, -1));

        alquilarH9.setForeground(new java.awt.Color(0, 0, 1));
        alquilarH9.setText("Alquilar");
        alquilarH9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH9ActionPerformed(evt);
            }
        });
        habDis.add(alquilarH9, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 620, -1, -1));

        alquilarH10.setForeground(new java.awt.Color(0, 0, 1));
        alquilarH10.setText("Alquilar");
        alquilarH10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alquilarH10ActionPerformed(evt);
            }
        });
        habDis.add(alquilarH10, new org.netbeans.lib.awtextra.AbsoluteConstraints(1210, 620, -1, -1));

        jButton4.setForeground(new java.awt.Color(0, 0, 1));
        jButton4.setText("Volver");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        habDis.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 110, 30));

        jButton5.setForeground(new java.awt.Color(0, 0, 1));
        jButton5.setText("Ir a Facturación");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        habDis.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 690, 190, 60));
        habDis.add(cod1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 95, 130, 20));
        habDis.add(cod2, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 95, 120, 20));
        habDis.add(cod3, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 95, 120, 20));
        habDis.add(cod4, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 95, 130, 20));
        habDis.add(cod5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 95, 130, 18));
        habDis.add(cod6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 395, 110, 20));
        habDis.add(cod7, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 395, 120, 20));
        habDis.add(cod8, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 395, 130, 20));
        habDis.add(cod9, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 395, 130, 20));
        habDis.add(cod10, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 395, 130, 20));

        jLabel52.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/disponibilidad.png"))); // NOI18N
        habDis.add(jLabel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1370, 770));

        getContentPane().add(habDis, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1366, 768));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void RentBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RentBActionPerformed
      
      habDis.setVisible(true);
      InformationPanel1.setVisible(false); 
      MainPanel.setVisible(false); 
      DatosHP.setVisible(false);
      facturaP.setVisible(false);
      LateralPanel.setVisible(false);
// TODO add your handling code here:
    }//GEN-LAST:event_RentBActionPerformed

    private void SwitchAccountBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SwitchAccountBActionPerformed
        // TODO add your handling code here:
        Login log=new Login();
        log.setVisible(true);  
        this.dispose();
    }//GEN-LAST:event_SwitchAccountBActionPerformed

    private void SwitchAccountB1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SwitchAccountB1ActionPerformed
       codeAdmin f=new codeAdmin();
        f.setVisible(true);
        f.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_SwitchAccountB1ActionPerformed

    private void FormBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FormBActionPerformed
    Proforma P =new Proforma();
    P.setVisible(true);
    P.setLocationRelativeTo(null);
    this.dispose();// TODO add your handling code here:
    }//GEN-LAST:event_FormBActionPerformed

    private void FormB1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FormB1ActionPerformed
        // TODO add your handling code here:
        CheckOut Co=new CheckOut();
        Co.setVisible(true);
        Co.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_FormB1ActionPerformed

    private void InformationBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InformationBActionPerformed
      MainPanel.setVisible(false);
      DatosHP.setVisible(false);
        facturaP.setVisible(false);
        habDis.setVisible(false);
      InformationPanel1.setVisible(true); 

// TODO add your handling code here:
    }//GEN-LAST:event_InformationBActionPerformed

    private void volverMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_volverMActionPerformed
    MainPanel.setVisible(true); 
      InformationPanel1.setVisible(false);  
      habDis.setVisible(false);
      DatosHP.setVisible(false);
        facturaP.setVisible(false);

// TODO add your handling code here:
    }//GEN-LAST:event_volverMActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        System.exit(0);   // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void idSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idSearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idSearchActionPerformed

    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed
        String userID = idSearch.getText();
        org.bson.Document query = new  org.bson.Document("Cedula", userID);
        long count= collection.countDocuments(query);
        if(userID.length()!=10 ){
            JOptionPane.showMessageDialog(null, "La cedula debe de tener 10 digitos", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }else{

            if(count<=0){
                JOptionPane.showMessageDialog(null, "La cedula ingresada no esta registrada", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }else{
                FindIterable< org.bson.Document> documents = collection.find(query);
                if (documents.iterator().hasNext()) {
                    for (org.bson.Document document : documents) {
                        name.setText(document.getString("Nombre"));
                        phone.setText(document.getString("Teléfono"));
                        id.setText(document.getString("Cedula"));
                    }
                    jLabel34.setText("¡Resultado encontrado!");
                }
            }}  // TODO add your handling code here:
    }//GEN-LAST:event_searchActionPerformed

    private void cancelar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelar1ActionPerformed
        DatosHP.setVisible(false);
        habDis.setVisible(true);
        facturaP.setVisible(false);    // TODO add your handling code here:
    }//GEN-LAST:event_cancelar1ActionPerformed
    public void HotelManagement() {
        // Inicialización de los componentes
        
        // Configurar el listener para el JDateChooser de inicio
        inicio.addPropertyChangeListener("date", evt -> {
            Date diaInicio = inicio.getDate();
            if (diaInicio != null) {
                fin.setMinSelectableDate(diaInicio); // Bloquear fechas anteriores
            }
        });
    }
    String precio;
    private void registrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registrarActionPerformed
        String nombre=name.getText();
        String telefono=phone.getText();
        String cedu=id.getText();
        String correo=mail.getText();
        Integer dias = 0;
        Date diaInicio = inicio.getDate();  // Obtén la fecha de inicio
        Date diaFin = fin.getDate();
        double price=0;
        if (diaInicio != null && diaFin != null) {
            long diff = diaFin.getTime() - diaInicio.getTime();
            dias = (int)(diff / (1000 * 60 * 60 * 24)); // Muestra el total de días
        } else {
            JOptionPane.showMessageDialog(this, "Por favor ingrese ambas fechas", "Error", JOptionPane.ERROR_MESSAGE);
        }
        // Verifica que el texto tenga al menos 9 caracteres
        if (precio.length() >= 8) {
            String priceString = precio.substring(8).trim(); // Extrae el texto a partir del noveno carácter y elimina espacios en blanco
            // Convierte el texto del precio a double
            price = Double.parseDouble(priceString);
            System.out.println("Precio extraído: " + price); // Imprime el precio
        }

        crearPDFFactura c=new crearPDFFactura();
        c.guardarFacBD(nombre, telefono, cedu, correo);
        c.crearPDF(tipoH.getText(), tip_H.getSelectedItem().toString(), dias, price, price*(double)dias, factura);
        JOptionPane.showMessageDialog(this, "Agregado", "Exito", JOptionPane.INFORMATION_MESSAGE);
        // TODO add your handling code here:
    }//GEN-LAST:event_registrarActionPerformed

    private void cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarActionPerformed
        habDis.setVisible(true);
        DatosHP.setVisible(false);
        facturaP.setVisible(false);
        jLabel13.setText("");
        tipoH.setText("");
        // TODO add your handling code here:
    }//GEN-LAST:event_cancelarActionPerformed

    private void facturarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_facturarActionPerformed
        String codHab=tipoH.getText();
        Date diaInicio = inicio.getDate();  // Obtén la fecha de inicio
        Date diaFin = fin.getDate();        // Obtén la fecha de fin
        int dias = 0;
        precio=jLabel13.getText();
        if (diaInicio != null && diaFin != null) {
            long diff = diaFin.getTime() - diaInicio.getTime();
            dias = (int)(diff / (1000 * 60 * 60 * 24)); // Muestra el total de días
        } else {
            JOptionPane.showMessageDialog(this, "Por favor ingrese ambas fechas", "Error", JOptionPane.ERROR_MESSAGE);
        }
        String tipHa = tip_H.getSelectedItem().toString();
        agregarDatosFa agg=new agregarDatosFa();
        agg.agregarDatosTabla(codHab,tipHa, dias,factura, subTotal, total,iva);
        // TODO add your handling code here:
    }//GEN-LAST:event_facturarActionPerformed

    private void tipoHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tipoHActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tipoHActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        String tipHa = tip_H.getSelectedItem().toString();
        disponibilidad d= new disponibilidad ();
        d.seedisp(tipHa,hab1, hab11, hab12, hab10, hab101,hab102, hab2,hab22, hab23, hab3,hab32,hab33, hab4,hab42,hab43,hab5,hab52,hab53,hab6,hab62,hab63,hab7,hab72,hab73,hab8,hab82,hab83,hab9,hab92,hab93,cod1,cod2,cod3,cod4,cod5,cod6,cod7,cod8,cod9,cod10);

    }//GEN-LAST:event_jButton3ActionPerformed

    private void alquilarH1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH1ActionPerformed
        String tip=cod1.getText();
        String pr=hab11.getText();
        jLabel13.setText(pr);
        tipoH.setText(tip);
        String dispo=hab1.getText();
        if ("Disponibilidad: Ocupado".equals(dispo) || "Disponibilidad: Pendiente".equals(dispo)) {
            // Mostrar un mensaje de error y terminar el método
            JOptionPane.showMessageDialog(this, "La habitación seleccionada no está disponible", "ERROR", JOptionPane.ERROR_MESSAGE);
            return; // Termina la ejecución del método
            // Mostrar el panel adecuado
        } else {
            DatosHP.setVisible(true);
            habDis.setVisible(false);
            facturaP.setVisible(false);
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_alquilarH1ActionPerformed

    private void alquilarH2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH2ActionPerformed
        String tip=cod2.getText();
        String pr=hab22.getText();
        jLabel13.setText(pr);
        tipoH.setText(tip);
        String dispo=hab2.getText();
        System.out.println(dispo);
        if ("Disponibilidad: Ocupado".equals(dispo) || "Disponibilidad: Pendiente".equals(dispo)) {
            // Mostrar un mensaje de error y terminar el método
            JOptionPane.showMessageDialog(this, "La habitación seleccionada no está disponible", "ERROR", JOptionPane.ERROR_MESSAGE);
            return; // Termina la ejecución del método
            // Mostrar el panel adecuado
        } else {
            DatosHP.setVisible(true);
            habDis.setVisible(false);
            facturaP.setVisible(false);
        }
    }//GEN-LAST:event_alquilarH2ActionPerformed

    private void alquilarH3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH3ActionPerformed
        String tip=cod3.getText();
        String pr=hab32.getText();
        jLabel13.setText(pr);
        tipoH.setText(tip);
        String dispo=hab3.getText();
        System.out.println(dispo);
        if ("Disponibilidad: Ocupado".equals(dispo) || "Disponibilidad: Pendiente".equals(dispo)) {
            JOptionPane.showMessageDialog(this, "La habitación seleccionada no está disponible", "ERROR", JOptionPane.ERROR_MESSAGE);
            return; 
        } else {
            DatosHP.setVisible(true);
            habDis.setVisible(false);
            facturaP.setVisible(false);
        }
    }//GEN-LAST:event_alquilarH3ActionPerformed

    private void alquilarH4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH4ActionPerformed
        String tip=cod4.getText();
        String pr=hab42.getText();
        jLabel13.setText(pr);
        tipoH.setText(tip);
        String dispo=hab4.getText();
        System.out.println(dispo);
        if ("Disponibilidad: Ocupado".equals(dispo) || "Disponibilidad: Pendiente".equals(dispo)) {
            // Mostrar un mensaje de error y terminar el método
            JOptionPane.showMessageDialog(this, "La habitación seleccionada no está disponible", "ERROR", JOptionPane.ERROR_MESSAGE);
            return; // Termina la ejecución del método
            // Mostrar el panel adecuado
        } else {
            DatosHP.setVisible(true);
            habDis.setVisible(false);
            facturaP.setVisible(false);
        }// TODO add your handling code here:
    }//GEN-LAST:event_alquilarH4ActionPerformed

    private void alquilarH5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH5ActionPerformed
        String tip=cod5.getText();
        String pr=hab52.getText();
        jLabel13.setText(pr);
        tipoH.setText(tip);
        String dispo=hab5.getText();
        System.out.println(dispo);
        if ("Disponibilidad: Ocupado".equals(dispo) || "Disponibilidad: Pendiente".equals(dispo)) {
            JOptionPane.showMessageDialog(this, "La habitación seleccionada no está disponible", "ERROR", JOptionPane.ERROR_MESSAGE);
            return; 
        } else {
            DatosHP.setVisible(true);
            habDis.setVisible(false);
            facturaP.setVisible(false);
        }// TODO add your handling code here:
    }//GEN-LAST:event_alquilarH5ActionPerformed

    private void alquilarH6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH6ActionPerformed
        String tip=cod6.getText();
        String pr=hab62.getText();
        jLabel13.setText(pr);
        tipoH.setText(tip);
        String dispo=hab6.getText();
        System.out.println(dispo);
        if ("Disponibilidad: Ocupado".equals(dispo) || "Disponibilidad: Pendiente".equals(dispo)) {
            JOptionPane.showMessageDialog(this, "La habitación seleccionada no está disponible", "ERROR", JOptionPane.ERROR_MESSAGE);
            return; 
        } else {
            DatosHP.setVisible(true);
            habDis.setVisible(false);
            facturaP.setVisible(false);
        }// TODO add your handling code here:
    }//GEN-LAST:event_alquilarH6ActionPerformed

    private void alquilarH7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH7ActionPerformed
        String tip=cod7.getText();
        String pr=hab72.getText();
        jLabel13.setText(pr);
        tipoH.setText(tip);
        String dispo=hab7.getText();
        System.out.println(dispo);
        if ("Disponibilidad: Ocupado".equals(dispo) || "Disponibilidad: Pendiente".equals(dispo)) {
            JOptionPane.showMessageDialog(this, "La habitación seleccionada no está disponible", "ERROR", JOptionPane.ERROR_MESSAGE);
            return;
        } else {
            DatosHP.setVisible(true);
            habDis.setVisible(false);
            facturaP.setVisible(false);
        }// TODO add your handling code here:
    }//GEN-LAST:event_alquilarH7ActionPerformed

    private void alquilarH8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH8ActionPerformed
        String tip=cod8.getText();
        String pr=hab82.getText();
        jLabel13.setText(pr);
        tipoH.setText(tip);
        String dispo=hab8.getText();
        System.out.println(dispo);
        if ("Disponibilidad: Ocupado".equals(dispo) || "Disponibilidad: Pendiente".equals(dispo)) {
            JOptionPane.showMessageDialog(this, "La habitación seleccionada no está disponible", "ERROR", JOptionPane.ERROR_MESSAGE);
            return; 
        } else {
            DatosHP.setVisible(true);
            habDis.setVisible(false);
            facturaP.setVisible(false);
        };// TODO add your handling code here:
    }//GEN-LAST:event_alquilarH8ActionPerformed

    private void alquilarH9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH9ActionPerformed
        String tip=cod9.getText();
        String pr=hab92.getText();
        jLabel13.setText(pr);
        tipoH.setText(tip);
        String dispo=hab9.getText();
        System.out.println(dispo);
        if ("Disponibilidad: Ocupado".equals(dispo) || "Disponibilidad: Pendiente".equals(dispo)) {
            JOptionPane.showMessageDialog(this, "La habitación seleccionada no está disponible", "ERROR", JOptionPane.ERROR_MESSAGE);
            return; 
        } else {
            DatosHP.setVisible(true);
            habDis.setVisible(false);
            facturaP.setVisible(false);
        }// TODO add your handling code here:
    }//GEN-LAST:event_alquilarH9ActionPerformed

    private void alquilarH10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alquilarH10ActionPerformed
        String tip=cod10.getText();
        String pr=hab101.getText();
        jLabel13.setText(pr);
        tipoH.setText(tip);
        String dispo=hab10.getText();
        System.out.println(dispo);
        if ("Disponibilidad: Ocupado".equals(dispo) || "Disponibilidad: Pendiente".equals(dispo)) {
            // Mostrar un mensaje de error y terminar el método
            JOptionPane.showMessageDialog(this, "La habitación seleccionada no está disponible", "ERROR", JOptionPane.ERROR_MESSAGE);
            return; // Termina la ejecución del método
            // Mostrar el panel adecuado
        } else {
            DatosHP.setVisible(true);
            habDis.setVisible(false);
            facturaP.setVisible(false);
        }// TODO add your handling code here:
    }//GEN-LAST:event_alquilarH10ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
       
      habDis.setVisible(false);
      InformationPanel1.setVisible(false); 
      MainPanel.setVisible(true); 
      DatosHP.setVisible(false);
      facturaP.setVisible(false);
      LateralPanel.setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        facturaP.setVisible(true);
        habDis.setVisible(false);
        DatosHP.setVisible(false);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principal_Hotel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principal_Hotel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principal_Hotel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principal_Hotel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Principal_Hotel().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel DatosHP;
    private javax.swing.JButton FormB;
    private javax.swing.JButton FormB1;
    private javax.swing.JButton InformationB;
    private javax.swing.JPanel InformationPanel1;
    private javax.swing.JPanel LateralPanel;
    private javax.swing.JLabel LogoL;
    public javax.swing.JLabel LogoLateralPanelL;
    private javax.swing.JPanel MainPanel;
    private javax.swing.JButton RentB;
    private javax.swing.JLabel SimpleRoomL3;
    private javax.swing.JLabel SimpleRoomL4;
    private javax.swing.JLabel SimpleRoomL5;
    private javax.swing.JButton SwitchAccountB;
    private javax.swing.JButton SwitchAccountB1;
    private javax.swing.JButton alquilarH1;
    private javax.swing.JButton alquilarH10;
    private javax.swing.JButton alquilarH2;
    private javax.swing.JButton alquilarH3;
    private javax.swing.JButton alquilarH4;
    private javax.swing.JButton alquilarH5;
    private javax.swing.JButton alquilarH6;
    private javax.swing.JButton alquilarH7;
    private javax.swing.JButton alquilarH8;
    private javax.swing.JButton alquilarH9;
    private javax.swing.JButton cancelar;
    private javax.swing.JButton cancelar1;
    private javax.swing.JLabel cod1;
    private javax.swing.JLabel cod10;
    private javax.swing.JLabel cod2;
    private javax.swing.JLabel cod3;
    private javax.swing.JLabel cod4;
    private javax.swing.JLabel cod5;
    private javax.swing.JLabel cod6;
    private javax.swing.JLabel cod7;
    private javax.swing.JLabel cod8;
    private javax.swing.JLabel cod9;
    private javax.swing.JTable factura;
    private javax.swing.JPanel facturaP;
    private javax.swing.JButton facturar;
    private com.toedter.calendar.JDateChooser fin;
    private javax.swing.JLabel hab1;
    private javax.swing.JLabel hab10;
    private javax.swing.JLabel hab101;
    private javax.swing.JLabel hab102;
    private javax.swing.JLabel hab11;
    private javax.swing.JLabel hab12;
    private javax.swing.JLabel hab2;
    private javax.swing.JLabel hab22;
    private javax.swing.JLabel hab23;
    private javax.swing.JLabel hab3;
    private javax.swing.JLabel hab32;
    private javax.swing.JLabel hab33;
    private javax.swing.JLabel hab4;
    private javax.swing.JLabel hab42;
    private javax.swing.JLabel hab43;
    private javax.swing.JLabel hab5;
    private javax.swing.JLabel hab52;
    private javax.swing.JLabel hab53;
    private javax.swing.JLabel hab6;
    private javax.swing.JLabel hab62;
    private javax.swing.JLabel hab63;
    private javax.swing.JLabel hab7;
    private javax.swing.JLabel hab72;
    private javax.swing.JLabel hab73;
    private javax.swing.JLabel hab8;
    private javax.swing.JLabel hab82;
    private javax.swing.JLabel hab83;
    private javax.swing.JLabel hab9;
    private javax.swing.JLabel hab92;
    private javax.swing.JLabel hab93;
    private javax.swing.JPanel habDis;
    private javax.swing.JTextField id;
    private javax.swing.JTextField idSearch;
    private com.toedter.calendar.JDateChooser inicio;
    private javax.swing.JTextField iva;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField mail;
    private javax.swing.JTextField name;
    private javax.swing.JTextField phone;
    private javax.swing.JButton registrar;
    private javax.swing.JButton search;
    private javax.swing.JTextField subTotal;
    private javax.swing.JComboBox<String> tip_H;
    private javax.swing.JTextField tipoH;
    private javax.swing.JTextField total;
    private javax.swing.JButton volverM;
    // End of variables declaration//GEN-END:variables
}
