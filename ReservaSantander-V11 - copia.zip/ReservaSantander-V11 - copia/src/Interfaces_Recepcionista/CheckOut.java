package Interfaces_Recepcionista;




import BD_Facturas.conexionBD;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;
import java.awt.Desktop;
import java.net.URI;

public class CheckOut extends javax.swing.JFrame {
    conexionBD iM = new conexionBD();
    private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoCollection<org.bson.Document> collection;
    public CheckOut() {
        initComponents();
        mongoClient = new MongoClient("localhost", 27017); 
        database = mongoClient.getDatabase("Reservas_Santander");
        collection = database.getCollection("RegistroClientes"); 
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tip_H = new javax.swing.JComboBox<>();
        jButton2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        CheckOut = new javax.swing.JToggleButton();
        CodigoHabitacion = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableP = new javax.swing.JTable();
        EPendiente = new javax.swing.JButton();
        Limpieza = new javax.swing.JButton();
        EDisponible = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(610, 560));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tip_H.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Personal", "Familiar", "Matrimonial" }));
        getContentPane().add(tip_H, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 70, 110, 30));

        jButton2.setText("Volver");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 110, 30));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setText("Seleccione el cambio de estado que desee realizar");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 310, -1, -1));

        CheckOut.setBackground(new java.awt.Color(73, 114, 116));
        CheckOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CheckOutActionPerformed(evt);
            }
        });
        getContentPane().add(CheckOut, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 110, 60, 30));
        getContentPane().add(CodigoHabitacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 110, 130, 30));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Ingrese el codigo de la habitacion: ");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 120, -1, -1));

        tableP.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tableP);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 190, 460, 60));

        EPendiente.setText("Estado Pendiente");
        EPendiente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EPendienteActionPerformed(evt);
            }
        });
        getContentPane().add(EPendiente, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 360, -1, -1));

        Limpieza.setText("Realizar limpieza");
        Limpieza.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LimpiezaActionPerformed(evt);
            }
        });
        getContentPane().add(Limpieza, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 400, -1, -1));

        EDisponible.setText("Estado disponible");
        EDisponible.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EDisponibleActionPerformed(evt);
            }
        });
        getContentPane().add(EDisponible, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 440, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Ingrese el tipo de la habitacion ");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 70, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    Principal_Hotel p=new Principal_Hotel();
    p.setVisible(true);
    p.setLocationRelativeTo(null);
    this.dispose();

    }//GEN-LAST:event_jButton2ActionPerformed

    private void CheckOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CheckOutActionPerformed
        String tipHa = tip_H.getSelectedItem().toString();
        String cod= CodigoHabitacion.getText();
        // TODO add your handling code here:
        if (tipHa.equals("Personal")) {
            tipHa = "H_personal";
        } else if (tipHa.equals("Familiar")) {
            tipHa = "H_familiar";
        } else {
            tipHa = "H_matrimonial";
        }
         iM.openMongo();
        MongoDatabase database = iM.getDatabase();
        MongoCollection<Document> collection = database.getCollection(tipHa);
        Document query = new Document("Codigo",cod);
        long count =collection.countDocuments(query);
        if(count<=0){
            JOptionPane.showMessageDialog(this, "No se ha encontrado la habitacion con el codigo indicado", "Error", JOptionPane.ERROR_MESSAGE);
            }else{

              DefaultTableModel tabla1 =  (DefaultTableModel) tableP.getModel();
              tabla1.setRowCount(0);
              FindIterable<Document> documents = collection.find(query);
              tabla1.setColumnIdentifiers(new String[] {"Estado","Precio", "Código"});
                 for(Document doc:documents){
              tabla1.addRow(new Object[]{doc.get("Disponibilidad"), doc.get("Precio"),doc.get("Codigo")});
          }tableP.setModel(tabla1);
       }
    }//GEN-LAST:event_CheckOutActionPerformed

    private void LimpiezaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LimpiezaActionPerformed
        
        String message = "Se necesita realizar limpieza en la habitacion " + CodigoHabitacion.getText();;

        try {
            // Codifica el mensaje para ser usado en la URL
            String encodedMessage = java.net.URLEncoder.encode(message, "UTF-8");
            String phoneNumber = "+593963483452"; // Asegúrate de reemplazar +34XXXXXXXXX con el número de teléfono correcto
            String urlString = "https://api.whatsapp.com/send?phone=" + phoneNumber + "&text=" + encodedMessage;

            // Imprime la URL para verificar que está construida correctamente
            System.out.println("URL generada: " + urlString);

            // Verifica si Desktop está soportado en la plataforma actual
            if (Desktop.isDesktopSupported()) {
                Desktop desktop = Desktop.getDesktop();
                // Verifica si se pueden abrir enlaces web
                if (desktop.isSupported(Desktop.Action.BROWSE)) {
                    URI uri = new URI(urlString);
                    desktop.browse(uri);
                } else {
                    JOptionPane.showMessageDialog(null, "No se puede abrir el navegador web en esta plataforma", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Desktop no está soportado en esta plataforma", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al intentar abrir el enlace web: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    
    }//GEN-LAST:event_LimpiezaActionPerformed

    private void EPendienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EPendienteActionPerformed
        // TODO add your handling code here:
        actualizarEstadoHabitacion("Pendiente");
    }//GEN-LAST:event_EPendienteActionPerformed

    private void EDisponibleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EDisponibleActionPerformed
        // TODO add your handling code here:
        actualizarEstadoHabitacion("Disponible");
    }//GEN-LAST:event_EDisponibleActionPerformed
    private void actualizarEstadoHabitacion(String nuevoEstado) {
        String tipHa = tip_H.getSelectedItem().toString();
        String cod = CodigoHabitacion.getText();
        if (tipHa.equals("Personal")) {
            tipHa = "H_personal";
        } else if (tipHa.equals("Familiar")) {
            tipHa = "H_familiar";
        } else {
            tipHa = "H_matrimonial";
        }
        iM.openMongo();
        MongoDatabase database = iM.getDatabase();
        MongoCollection<Document> collection = database.getCollection(tipHa);
        Document query = new Document("Codigo", cod);
        Document update = new Document("$set", new Document("Disponibilidad", nuevoEstado));
        collection.updateOne(query, update);
        JOptionPane.showMessageDialog(this, "El estado de la habitación ha sido cambiado a " + nuevoEstado);
        CheckOutActionPerformed(null); // Refrescar la tabla
    }
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CheckOut().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton CheckOut;
    private javax.swing.JTextField CodigoHabitacion;
    private javax.swing.JButton EDisponible;
    private javax.swing.JButton EPendiente;
    private javax.swing.JButton Limpieza;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tableP;
    private javax.swing.JComboBox<String> tip_H;
    // End of variables declaration//GEN-END:variables
}
