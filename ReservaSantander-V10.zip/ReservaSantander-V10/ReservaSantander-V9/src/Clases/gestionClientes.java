/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import BD_Facturas.conexionBD;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

/**
 *
 * @author HP
 */
public class gestionClientes {
    conexionBD iM = new conexionBD();
  public void seeClients(JTable seeUsser){
  iM.openMongo();
  MongoDatabase database = iM.getDatabase();
  MongoCollection<Document> collection = database.getCollection("RegistroClientes");
  DefaultTableModel tabla1 = new DefaultTableModel();
  FindIterable<Document> documents = collection.find();
  tabla1.setColumnIdentifiers(new String[] {"Nombre","Cedula", "Telefono"});
  for(Document doc:documents){
      tabla1.addRow(new Object[]{doc.get("Nombre"), doc.get("Cedula"),doc.get("Teléfono")});
  }seeUsser.setModel(tabla1);
 // JOptionPane.showMessageDialog(null, "Tabla actualizada", "Exito", JOptionPane.INFORMATION_MESSAGE);
  
}
public void validData(String idSearch,JTable updateTable ){
   try{
        if (!idSearch.matches("\\d{10}")) {
          JOptionPane.showMessageDialog(null, "Ingrese una cedula válida", "Error", JOptionPane.ERROR_MESSAGE);
          return;
        }} catch (NumberFormatException e) {
         JOptionPane.showMessageDialog(null, "Ingrese una cedula válida", "Error", JOptionPane.ERROR_MESSAGE);
         return;
    } 
   searchClient( idSearch, updateTable);
 }
 public void searchClient(String idSearch,JTable updateTable){
     iM.openMongo();
     MongoDatabase database = iM.getDatabase();
     MongoCollection<Document> collection = database.getCollection("RegistroClientes");
     Document query = new Document("Cedula", idSearch);
     long count= collection.countDocuments(query);
     if(count<=0){
        JOptionPane.showMessageDialog(null, "La cedula ingresada no se encuentra dentro del registro", "Error", JOptionPane.ERROR_MESSAGE);
        return;     
     }else{
        DefaultTableModel tableModel = (DefaultTableModel) updateTable.getModel();
        tableModel.setRowCount(0);
        tableModel.setColumnIdentifiers(new String []{"Nombre","Cedula","Teléfono"});
        FindIterable<Document> documents = collection.find(query);
        for (Document document : documents) {
           tableModel.addRow(new Object[]{
            document.get("Nombre"),
            document.get("Cedula"),
            document.get("Teléfono")
           });}
         updateTable.setModel(tableModel);
         updateTable.revalidate();
         updateTable.repaint();
     }
 } 
     public void deleteClient(JTable updateTable,String idSearch){
    iM.openMongo();
    MongoDatabase database = iM.getDatabase();
    MongoCollection<Document> collection = database.getCollection("RegistroClientes");
    Document query = new Document("Cedula", idSearch);
    collection.deleteOne(query);
    JOptionPane.showMessageDialog(null, "Usuario eliminado exitosamente", "Exito", JOptionPane.INFORMATION_MESSAGE);
   }
}
