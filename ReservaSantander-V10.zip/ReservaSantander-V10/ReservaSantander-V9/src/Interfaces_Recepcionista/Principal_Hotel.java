package Interfaces_Recepcionista;

import Interfaces_Admin.GestionAdmin;
import Interfaces_Admin.codeAdmin;
import java.awt.Dimension;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Toolkit;
import javax.swing.ImageIcon;
import tipografias.Fuentes;

public class Principal_Hotel extends javax.swing.JFrame {
    
    Fuentes tipoFuente;
    ImageIcon icon = new ImageIcon("src/Imagenes/HotelSantanderIcon.png");
    
    public Principal_Hotel() {
        initComponents();
        
        tipoFuente = new Fuentes();
        this.setLocationRelativeTo(null);
        this.setExtendedState(MAXIMIZED_BOTH);
        this.setTitle("Hotel Santander");
        rsscalelabel.RSScaleLabel.setScaleLabel(LogoLateralPanelL, "src/imagenes/HotelSantanderIcon.png");
        rsscalelabel.RSScaleLabel.setScaleLabel(LogoL, "src/imagenes/HotelSantanderIcon.png");
        
        this.setIconImage(icon.getImage());
        
        //update text font
        RentB.setFont(tipoFuente.fuente(tipoFuente.QS,1,25));
        InformationB.setFont(tipoFuente.fuente(tipoFuente.QS,1,18));
        //CleanningB.setFont(tipoFuente.fuente(tipoFuente.QS,1,18));
       
        FormB.setFont(tipoFuente.fuente(tipoFuente.QS,1,18));
        FormB1.setFont(tipoFuente.fuente(tipoFuente.QS,1,18));
        SwitchAccountB.setFont(tipoFuente.fuente(tipoFuente.QS,1,18));
        SwitchAccountB1.setFont(tipoFuente.fuente(tipoFuente.QS,1,18));
    }
    
    public void setResolution(){
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        
        // Obtener el dispositivo gráfico principal
        GraphicsDevice[] gs = ge.getScreenDevices();
        for (GraphicsDevice gd : gs) {
            // Obtener la configuración de pantalla del dispositivo
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            
            // Obtener el ancho y alto de la pantalla
            int width = screenSize.width;
            int height = screenSize.height;
            
            // Imprimir la resolución de la pantalla
            System.out.println("Resolución de la pantalla: " + width + "x" + height);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        LateralPanel = new javax.swing.JPanel();
        AboutB = new javax.swing.JButton();
        LogoLateralPanelL = new javax.swing.JLabel();
        InformationB = new javax.swing.JButton();
        FormB = new javax.swing.JButton();
        SwitchAccountB = new javax.swing.JButton();
        DocumentationB = new javax.swing.JButton();
        SwitchAccountB1 = new javax.swing.JButton();
        FormB1 = new javax.swing.JButton();
        MainPanel = new javax.swing.JPanel();
        LogoL = new javax.swing.JLabel();
        RentB = new javax.swing.JButton();
        InformationPanel1 = new javax.swing.JPanel();
        SimpleRoomL3 = new javax.swing.JLabel();
        SimpleRoomL4 = new javax.swing.JLabel();
        SimpleRoomL5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        LateralPanel.setBackground(new java.awt.Color(177, 203, 192));
        LateralPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        AboutB.setBackground(new java.awt.Color(73, 114, 116));
        AboutB.setForeground(new java.awt.Color(255, 255, 255));
        AboutB.setText("Acerca de");
        LateralPanel.add(AboutB, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 960, 140, -1));
        LateralPanel.add(LogoLateralPanelL, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, 260, 260));

        InformationB.setBackground(new java.awt.Color(73, 114, 116));
        InformationB.setForeground(new java.awt.Color(255, 255, 255));
        InformationB.setText("Informacion");
        InformationB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InformationBActionPerformed(evt);
            }
        });
        LateralPanel.add(InformationB, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 460, 290, -1));

        FormB.setBackground(new java.awt.Color(73, 114, 116));
        FormB.setForeground(new java.awt.Color(255, 255, 255));
        FormB.setText("Proforma");
        FormB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FormBActionPerformed(evt);
            }
        });
        LateralPanel.add(FormB, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 500, 290, -1));

        SwitchAccountB.setBackground(new java.awt.Color(73, 114, 116));
        SwitchAccountB.setForeground(new java.awt.Color(255, 255, 255));
        SwitchAccountB.setText("Logout");
        SwitchAccountB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SwitchAccountBActionPerformed(evt);
            }
        });
        LateralPanel.add(SwitchAccountB, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 620, 290, -1));

        DocumentationB.setBackground(new java.awt.Color(73, 114, 116));
        DocumentationB.setForeground(new java.awt.Color(255, 255, 255));
        DocumentationB.setText("Documentacion");
        LateralPanel.add(DocumentationB, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 960, 120, -1));

        SwitchAccountB1.setBackground(new java.awt.Color(73, 114, 116));
        SwitchAccountB1.setForeground(new java.awt.Color(255, 255, 255));
        SwitchAccountB1.setText("Gestiones Administrador");
        SwitchAccountB1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SwitchAccountB1ActionPerformed(evt);
            }
        });
        LateralPanel.add(SwitchAccountB1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 580, 290, -1));

        FormB1.setBackground(new java.awt.Color(73, 114, 116));
        FormB1.setForeground(new java.awt.Color(255, 255, 255));
        FormB1.setText("CheckOut y Limpieza");
        FormB1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FormB1ActionPerformed(evt);
            }
        });
        LateralPanel.add(FormB1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 540, 290, -1));

        getContentPane().add(LateralPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 390, 1090));

        MainPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        MainPanel.add(LogoL, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 80, 450, 450));

        RentB.setBackground(new java.awt.Color(73, 114, 116));
        RentB.setForeground(new java.awt.Color(255, 255, 255));
        RentB.setText("Alquilar");
        RentB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RentBActionPerformed(evt);
            }
        });
        MainPanel.add(RentB, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 600, 290, 80));

        getContentPane().add(MainPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 0, 1570, 1080));

        InformationPanel1.setBackground(new java.awt.Color(255, 255, 255));
        InformationPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        SimpleRoomL3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/HabMat.jpg"))); // NOI18N
        SimpleRoomL3.setText("exampleimage3");
        InformationPanel1.add(SimpleRoomL3, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 140, 220, 220));

        SimpleRoomL4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/habPersonal.jpg"))); // NOI18N
        SimpleRoomL4.setText("exampleimage1");
        InformationPanel1.add(SimpleRoomL4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 140, 220, 220));

        SimpleRoomL5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/HabFam.jpg"))); // NOI18N
        SimpleRoomL5.setText("exampleimage2");
        InformationPanel1.add(SimpleRoomL5, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 140, 220, 220));

        jLabel1.setText("Disponibilidad de cama adicional");
        InformationPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 590, -1, 20));

        jLabel2.setText("$$ 60-70");
        InformationPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 370, -1, -1));

        jLabel3.setText("Descripcion");
        InformationPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 410, -1, -1));

        jLabel4.setText("Habitacion Familiar");
        InformationPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 100, -1, -1));

        jLabel5.setText("Descripcion");
        InformationPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 400, -1, -1));

        jLabel6.setText("Habitacion Matrimonial");
        InformationPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 100, -1, -1));

        jButton1.setText("Volver");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        InformationPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 0, -1, -1));

        jLabel7.setText("Descripcion");
        InformationPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 410, -1, -1));

        jLabel12.setText("2 Habitaciones con vista al mar");
        InformationPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 470, -1, 20));

        jLabel14.setText("2 Habitaciones con vista al mar");
        InformationPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 470, -1, 20));

        jLabel15.setText("Selección de almohadas en la habitación");
        InformationPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 500, -1, 20));

        jLabel16.setText("Wifi Gratis");
        InformationPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 530, -1, 20));

        jLabel18.setText("1 Cama matrimonial ");
        InformationPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 440, -1, 20));

        jLabel17.setText("Area de estar");
        InformationPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 560, -1, 20));

        jLabel19.setText("Wifi Gratis");
        InformationPanel1.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 530, -1, 20));

        jLabel20.setText("2 Habitaciones con vista al mar");
        InformationPanel1.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 470, -1, 20));

        jLabel21.setText("Selección de almohadas en la habitación");
        InformationPanel1.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 500, -1, 20));

        jLabel22.setText("Disponibilidad de cama adicional");
        InformationPanel1.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 560, -1, 20));

        jLabel23.setText("Wifi Gratis");
        InformationPanel1.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 500, -1, 20));

        jLabel24.setText("1 Cama individual");
        InformationPanel1.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 440, -1, 20));

        jLabel25.setText("1 Cama matrimonial y 2 camas personales");
        InformationPanel1.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 440, -1, 20));

        jLabel8.setText("Habitación Personal");
        InformationPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 110, -1, -1));

        jLabel9.setText("$$ 30-40");
        InformationPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 370, -1, -1));

        jLabel10.setText("$$ 80-100");
        InformationPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 370, -1, -1));

        getContentPane().add(InformationPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 0, 1570, 1080));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void RentBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RentBActionPerformed
      Disponibilidad d=new Disponibilidad();
      d.setVisible(true);
      d.setLocationRelativeTo(null);
      this.dispose();
// TODO add your handling code here:
    }//GEN-LAST:event_RentBActionPerformed

    private void SwitchAccountBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SwitchAccountBActionPerformed
        // TODO add your handling code here:
        Login log=new Login();
        log.setVisible(true);  
        this.dispose();
    }//GEN-LAST:event_SwitchAccountBActionPerformed

    private void SwitchAccountB1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SwitchAccountB1ActionPerformed
       codeAdmin f=new codeAdmin();
        f.setVisible(true);
        f.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_SwitchAccountB1ActionPerformed

    private void FormBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FormBActionPerformed
    Proforma P =new Proforma();
    P.setVisible(true);
    this.dispose();// TODO add your handling code here:
    }//GEN-LAST:event_FormBActionPerformed

    private void FormB1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FormB1ActionPerformed
        // TODO add your handling code here:
        CheckOut Co=new CheckOut();
        Co.setVisible(true);
        Co.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_FormB1ActionPerformed

    private void InformationBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InformationBActionPerformed
      MainPanel.setVisible(false); 
      InformationPanel1.setVisible(true); 

// TODO add your handling code here:
    }//GEN-LAST:event_InformationBActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    MainPanel.setVisible(true); 
      InformationPanel1.setVisible(false);     // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principal_Hotel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principal_Hotel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principal_Hotel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principal_Hotel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Principal_Hotel().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AboutB;
    private javax.swing.JButton DocumentationB;
    private javax.swing.JButton FormB;
    private javax.swing.JButton FormB1;
    private javax.swing.JButton InformationB;
    private javax.swing.JPanel InformationPanel1;
    private javax.swing.JPanel LateralPanel;
    private javax.swing.JLabel LogoL;
    private javax.swing.JLabel LogoLateralPanelL;
    private javax.swing.JPanel MainPanel;
    private javax.swing.JButton RentB;
    private javax.swing.JLabel SimpleRoomL3;
    private javax.swing.JLabel SimpleRoomL4;
    private javax.swing.JLabel SimpleRoomL5;
    private javax.swing.JButton SwitchAccountB;
    private javax.swing.JButton SwitchAccountB1;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    // End of variables declaration//GEN-END:variables
}
