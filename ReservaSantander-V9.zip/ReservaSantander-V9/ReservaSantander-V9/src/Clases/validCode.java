package Clases;
import Interfaces_Admin.GestionAdmin;
import javax.swing.JOptionPane;
public class validCode {
    //Instanciación de la clase llenarCampos
    public void validCodeAdmin(String Password, java.awt.Component componente){
     if(Password.isEmpty()){
         JOptionPane.showMessageDialog(null, "Debes llenar todos los campos","Campos vacios",JOptionPane.WARNING_MESSAGE);       
     }else{ // Verificar si se encontraron resultados
            if ("A1234".equals(Password)) {
               GestionAdmin H = new GestionAdmin();
               H.setVisible(true);
               H.setLocationRelativeTo(null);
               closeVentana(componente);
            } else {
               JOptionPane.showMessageDialog(null, "Contraseña incorrecta", "Inicio Fallido", JOptionPane.ERROR_MESSAGE);
            }
        }   
    }
    private static void closeVentana(java.awt.Component componente) {
        if (componente instanceof javax.swing.JFrame) {
            ((javax.swing.JFrame) componente).dispose();
        }
    }
}
